<?php
$page_title = 'Table Bookings';
require_once 'includes/header.php';

// Mock bookings data - in production, fetch from database
$bookings = [
    ['id' => 1, 'full_name' => 'John Smith', 'email' => 'john.smith@email.com', 'date_time' => '2026-03-23 19:00:00', 'no_people' => 4, 'table_number' => 'T-05', 'message' => 'Anniversary dinner', 'status' => 'confirmed'],
    ['id' => 2, 'full_name' => 'Sarah Johnson', 'email' => 'sarah.j@email.com', 'date_time' => '2026-03-23 20:30:00', 'no_people' => 2, 'table_number' => 'T-12', 'message' => 'Window seat preferred', 'status' => 'pending'],
    ['id' => 3, 'full_name' => 'Michael Brown', 'email' => 'm.brown@email.com', 'date_time' => '2026-03-24 18:00:00', 'no_people' => 6, 'table_number' => 'T-08', 'message' => 'Family celebration', 'status' => 'confirmed'],
    ['id' => 4, 'full_name' => 'Emily Davis', 'email' => 'emily.davis@email.com', 'date_time' => '2026-03-25 19:30:00', 'no_people' => 3, 'table_number' => 'T-03', 'message' => '', 'status' => 'pending'],
    ['id' => 5, 'full_name' => 'Robert Wilson', 'email' => 'rwilson@email.com', 'date_time' => '2026-03-22 20:00:00', 'no_people' => 5, 'table_number' => 'T-10', 'message' => 'Business dinner', 'status' => 'completed'],
    ['id' => 6, 'full_name' => 'Lisa Anderson', 'email' => 'lisa.a@email.com', 'date_time' => '2026-03-26 18:30:00', 'no_people' => 2, 'table_number' => 'T-15', 'message' => 'Date night', 'status' => 'confirmed'],
    ['id' => 7, 'full_name' => 'David Martinez', 'email' => 'd.martinez@email.com', 'date_time' => '2026-03-24 19:00:00', 'no_people' => 8, 'table_number' => 'T-20', 'message' => 'Birthday party', 'status' => 'confirmed'],
    ['id' => 8, 'full_name' => 'Jennifer Taylor', 'email' => 'j.taylor@email.com', 'date_time' => '2026-03-27 20:00:00', 'no_people' => 4, 'table_number' => 'T-06', 'message' => '', 'status' => 'cancelled'],
];

// Calculate stats
$stats = [
    'total' => count($bookings),
    'pending' => count(array_filter($bookings, fn($b) => $b['status'] === 'pending')),
    'confirmed' => count(array_filter($bookings, fn($b) => $b['status'] === 'confirmed')),
    'completed' => count(array_filter($bookings, fn($b) => $b['status'] === 'completed')),
];

function getStatusBadge($status) {
    $badges = [
        'confirmed' => '<span class="badge badge-confirmed"><i class="fas fa-check-circle me-1"></i>Confirmed</span>',
        'pending' => '<span class="badge badge-pending"><i class="fas fa-clock me-1"></i>Pending</span>',
        'cancelled' => '<span class="badge badge-cancelled"><i class="fas fa-times-circle me-1"></i>Cancelled</span>',
        'completed' => '<span class="badge badge-completed"><i class="fas fa-check-circle me-1"></i>Completed</span>',
    ];
    return $badges[$status] ?? '<span class="badge bg-secondary">' . ucfirst($status) . '</span>';
}

// Handle status update
if (isset($_GET['action']) && $_GET['action'] === 'update_status' && isset($_GET['id']) && isset($_GET['status'])) {
    // In production: Update database
    header("Location: table-bookings.php");
    exit();
}

// Handle delete
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    // In production: Delete from database
    header("Location: table-bookings.php");
    exit();
}
?>

<!-- Stats Cards -->
<div class="row fade-in">
    <div class="col-md-3 mb-4">
        <div class="stat-card">
            <div class="stat-header">
                <div>
                    <div class="stat-title">Total Bookings</div>
                    <div class="stat-value"><?php echo $stats['total']; ?></div>
                </div>
                <div class="stat-icon blue">
                    <i class="fas fa-calendar-alt"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="stat-card">
            <div class="stat-header">
                <div>
                    <div class="stat-title">Pending</div>
                    <div class="stat-value text-amber-600"><?php echo $stats['pending']; ?></div>
                </div>
                <div class="stat-icon amber">
                    <i class="fas fa-clock"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="stat-card">
            <div class="stat-header">
                <div>
                    <div class="stat-title">Confirmed</div>
                    <div class="stat-value text-green-600"><?php echo $stats['confirmed']; ?></div>
                </div>
                <div class="stat-icon green">
                    <i class="fas fa-check-circle"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="stat-card">
            <div class="stat-header">
                <div>
                    <div class="stat-title">Completed</div>
                    <div class="stat-value text-blue-600"><?php echo $stats['completed']; ?></div>
                </div>
                <div class="stat-icon blue">
                    <i class="fas fa-users"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Main Card -->
<div class="card fade-in">
    <div class="card-header">
        <div class="row align-items-center">
            <div class="col-md-4">
                <h5 class="card-title mb-0">All Table Bookings</h5>
            </div>
            <div class="col-md-8">
                <div class="d-flex gap-2 justify-content-md-end">
                    <div class="search-box">
                        <i class="fas fa-search"></i>
                        <input type="text" class="form-control" placeholder="Search bookings..." id="searchInput">
                    </div>
                    <select class="form-select" style="width: 150px;" id="statusFilter">
                        <option value="all">All Status</option>
                        <option value="pending">Pending</option>
                        <option value="confirmed">Confirmed</option>
                        <option value="completed">Completed</option>
                        <option value="cancelled">Cancelled</option>
                    </select>
                    <button class="btn btn-outline-secondary">
                        <i class="fas fa-download"></i>
                    </button>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addBookingModal">
                        <i class="fas fa-plus me-2"></i>Add Booking
                    </button>
                </div>
            </div>
        </div>
    </div>
    <div class="card-body p-0">
        <div class="table-container">
            <table class="table" id="bookingsTable">
                <thead>
                    <tr>
                        <th>Customer</th>
                        <th>Date & Time</th>
                        <th>Guests</th>
                        <th>Table</th>
                        <th>Status</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($bookings as $booking): ?>
                    <tr data-status="<?php echo $booking['status']; ?>">
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <div class="customer-avatar">
                                    <?php echo strtoupper(substr($booking['full_name'], 0, 1) . substr(strstr($booking['full_name'], ' '), 1, 1)); ?>
                                </div>
                                <div>
                                    <div class="fw-semibold"><?php echo $booking['full_name']; ?></div>
                                    <small class="text-muted"><?php echo $booking['email']; ?></small>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <i class="fas fa-calendar text-muted"></i>
                                <div>
                                    <div><?php echo date('M d, Y', strtotime($booking['date_time'])); ?></div>
                                    <small class="text-muted"><?php echo date('h:i A', strtotime($booking['date_time'])); ?></small>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <i class="fas fa-users text-muted"></i>
                                <span><?php echo $booking['no_people']; ?> guests</span>
                            </div>
                        </td>
                        <td>
                            <span class="badge bg-light text-dark border"><?php echo $booking['table_number']; ?></span>
                        </td>
                        <td><?php echo getStatusBadge($booking['status']); ?></td>
                        <td class="text-end">
                            <div class="dropdown">
                                <button class="btn-action" data-bs-toggle="dropdown">
                                    <i class="fas fa-ellipsis-v"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li>
                                        <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#viewModal<?php echo $booking['id']; ?>">
                                            <i class="fas fa-eye me-2 text-primary"></i>View Details
                                        </a>
                                    </li>
                                    <?php if ($booking['status'] === 'pending'): ?>
                                    <li>
                                        <a class="dropdown-item" href="?action=update_status&id=<?php echo $booking['id']; ?>&status=confirmed">
                                            <i class="fas fa-check-circle me-2 text-success"></i>Confirm
                                        </a>
                                    </li>
                                    <?php endif; ?>
                                    <?php if ($booking['status'] !== 'cancelled' && $booking['status'] !== 'completed'): ?>
                                    <li>
                                        <a class="dropdown-item" href="?action=update_status&id=<?php echo $booking['id']; ?>&status=cancelled">
                                            <i class="fas fa-times-circle me-2 text-danger"></i>Cancel
                                        </a>
                                    </li>
                                    <?php endif; ?>
                                    <li><hr class="dropdown-divider"></li>
                                    <li>
                                        <a class="dropdown-item text-danger" href="?action=delete&id=<?php echo $booking['id']; ?>" onclick="return confirm('Are you sure you want to delete this booking?')">
                                            <i class="fas fa-trash me-2"></i>Delete
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </td>
                    </tr>
                    
                    <!-- View Modal -->
                    <div class="modal fade" id="viewModal<?php echo $booking['id']; ?>" tabindex="-1">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Booking Details</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="d-flex align-items-center gap-3 mb-4">
                                        <div class="customer-avatar" style="width: 60px; height: 60px; font-size: 20px;">
                                            <?php echo strtoupper(substr($booking['full_name'], 0, 1) . substr(strstr($booking['full_name'], ' '), 1, 1)); ?>
                                        </div>
                                        <div>
                                            <h5 class="mb-1"><?php echo $booking['full_name']; ?></h5>
                                            <p class="text-muted mb-0"><?php echo $booking['email']; ?></p>
                                        </div>
                                    </div>
                                    <div class="row g-3">
                                        <div class="col-6">
                                            <div class="p-3 bg-light rounded">
                                                <small class="text-muted">Date</small>
                                                <p class="mb-0 fw-semibold"><?php echo date('M d, Y', strtotime($booking['date_time'])); ?></p>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="p-3 bg-light rounded">
                                                <small class="text-muted">Time</small>
                                                <p class="mb-0 fw-semibold"><?php echo date('h:i A', strtotime($booking['date_time'])); ?></p>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="p-3 bg-light rounded">
                                                <small class="text-muted">Guests</small>
                                                <p class="mb-0 fw-semibold"><?php echo $booking['no_people']; ?> people</p>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="p-3 bg-light rounded">
                                                <small class="text-muted">Table</small>
                                                <p class="mb-0 fw-semibold"><?php echo $booking['table_number']; ?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <?php if ($booking['message']): ?>
                                    <div class="mt-3 p-3 bg-light rounded">
                                        <small class="text-muted"><i class="fas fa-comment me-2"></i>Special Request</small>
                                        <p class="mb-0 mt-1"><?php echo $booking['message']; ?></p>
                                    </div>
                                    <?php endif; ?>
                                    <div class="mt-3 d-flex justify-content-between align-items-center">
                                        <span class="text-muted">Status</span>
                                        <?php echo getStatusBadge($booking['status']); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Booking Modal -->
<div class="modal fade" id="addBookingModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Booking</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Full Name</label>
                            <input type="text" name="full_name" class="form-control" placeholder="Customer name" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control" placeholder="email@example.com" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Date & Time</label>
                            <input type="datetime-local" name="date_time" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Number of Guests</label>
                            <input type="number" name="no_people" class="form-control" min="1" placeholder="4" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Table Number</label>
                            <input type="text" name="table_number" class="form-control" placeholder="T-01" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Special Request</label>
                            <textarea name="message" class="form-control" rows="3" placeholder="Any special requirements..."></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Create Booking</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Search functionality
document.getElementById('searchInput').addEventListener('input', function() {
    const searchTerm = this.value.toLowerCase();
    const rows = document.querySelectorAll('#bookingsTable tbody tr');
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(searchTerm) ? '' : 'none';
    });
});

// Status filter
document.getElementById('statusFilter').addEventListener('change', function() {
    const status = this.value;
    const rows = document.querySelectorAll('#bookingsTable tbody tr');
    
    rows.forEach(row => {
        if (status === 'all' || row.dataset.status === status) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
});
</script>

<?php require_once 'includes/footer.php'; ?>
