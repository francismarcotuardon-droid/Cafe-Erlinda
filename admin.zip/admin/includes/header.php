<?php
require_once 'session.php';
requireLogin();

$current_page = basename($_SERVER['PHP_SELF'], '.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? 'Dashboard'; ?> - Cafè Erlinda Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="css/admin-style.css" rel="stylesheet">
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo-container">
                <div class="logo-icon">
                    <i class="fas fa-utensils"></i>
                </div>
                <div class="logo-text">
                    <h5>Cafè Erlinda</h5>
                    <small>Admin Panel</small>
                </div>
            </div>
        </div>
        
        <nav class="sidebar-nav">
            <div class="nav-item">
                <a href="index.php" class="nav-link <?php echo $current_page === 'index' ? 'active' : ''; ?>">
                    <i class="fas fa-chart-pie"></i>
                    <span>Dashboard</span>
                </a>
            </div>
            <div class="nav-item">
                <a href="table-bookings.php" class="nav-link <?php echo $current_page === 'table-bookings' ? 'active' : ''; ?>">
                    <i class="fas fa-calendar-alt"></i>
                    <span>Table Bookings</span>
                </a>
            </div>
            <div class="nav-item">
                <a href="catering.php" class="nav-link <?php echo $current_page === 'catering' ? 'active' : ''; ?>">
                    <i class="fas fa-glass-cheers"></i>
                    <span>Catering</span>
                </a>
            </div>
            <div class="nav-item">
                <a href="menu.php" class="nav-link <?php echo $current_page === 'menu' ? 'active' : ''; ?>">
                    <i class="fas fa-utensils"></i>
                    <span>Menu Management</span>
                </a>
            </div>
            <div class="nav-item">
                <a href="settings.php" class="nav-link <?php echo $current_page === 'settings' ? 'active' : ''; ?>">
                    <i class="fas fa-cog"></i>
                    <span>Settings</span>
                </a>
            </div>
        </nav>
        
        <div class="sidebar-footer">
            <a href="logout.php" class="btn-logout">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>
    </aside>
    
    <!-- Main Content -->
    <main class="main-content" id="mainContent">
        <!-- Header -->
        <header class="header">
            <div class="header-left">
                <button class="btn-toggle" id="sidebarToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <h2 class="header-title"><?php echo $page_title ?? 'Dashboard'; ?></h2>
            </div>
            <div class="header-right">
                <button class="btn-notification">
                    <i class="fas fa-bell"></i>
                    <span class="notification-badge">3</span>
                </button>
                <div class="user-profile dropdown">
                    <div class="user-avatar">AD</div>
                    <div class="user-info d-none d-md-block">
                        <div class="user-name"><?php echo $_SESSION['admin_name'] ?? 'Admin'; ?></div>
                        <div class="user-role">Administrator</div>
                    </div>
                    <i class="fas fa-chevron-down ms-2 text-muted d-none d-md-block"></i>
                </div>
            </div>
        </header>
        
        <!-- Content Area -->
        <div class="content-area">
