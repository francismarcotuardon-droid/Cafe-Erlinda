<?php
session_start();

function isLoggedIn() {
    return isset($_SESSION['admin_id']) && $_SESSION['admin_id'] !== '';
}

function requireLogin() {
    if (!isLoggedIn()) {
        header("Location: login.php");
        exit();
    }
}

function logout() {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit();
}
?>
