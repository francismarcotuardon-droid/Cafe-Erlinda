<?php
$page_title = 'Dashboard';
require_once 'includes/header.php';

// Mock statistics - in production, fetch from database
$stats = [
    'total_bookings' => 156,
    'pending_bookings' => 18,
    'confirmed_bookings' => 127,
    'today_bookings' => 12,
    'total_catering' => 42,
    'weekly_revenue' => 8750.50
];

// Mock recent bookings
$recent_bookings = [
    ['id' => 1, 'name' => 'John Smith', 'email' => 'john.smith@email.com', 'date' => '2026-03-23', 'time' => '19:00', 'guests' => 4, 'table' => 'T-05', 'status' => 'confirmed'],
    ['id' => 2, 'name' => 'Sarah Johnson', 'email' => 'sarah.j@email.com', 'date' => '2026-03-23', 'time' => '20:30', 'guests' => 2, 'table' => 'T-12', 'status' => 'pending'],
    ['id' => 3, 'name' => 'Michael Brown', 'email' => 'm.brown@email.com', 'date' => '2026-03-24', 'time' => '18:00', 'guests' => 6, 'table' => 'T-08', 'status' => 'confirmed'],
    ['id' => 4, 'name' => 'Emily Davis', 'email' => 'emily.davis@email.com', 'date' => '2026-03-25', 'time' => '19:30', 'guests' => 3, 'table' => 'T-03', 'status' => 'pending'],
    ['id' => 5, 'name' => 'Lisa Anderson', 'email' => 'lisa.a@email.com', 'date' => '2026-03-26', 'time' => '18:30', 'guests' => 2, 'table' => 'T-15', 'status' => 'confirmed'],
];

// Mock recent catering
$recent_catering = [
    ['id' => 1, 'name' => 'Amanda White', 'event_type' => 'birthday', 'guests' => 30, 'date' => '2026-03-28', 'status' => 'confirmed'],
    ['id' => 2, 'name' => 'James Thompson', 'event_type' => 'anniversary', 'guests' => 50, 'date' => '2026-04-05', 'status' => 'pending'],
    ['id' => 3, 'name' => 'Patricia Lee', 'event_type' => 'reunion', 'guests' => 80, 'date' => '2026-04-12', 'status' => 'confirmed'],
];

function getStatusBadge($status) {
    $badges = [
        'confirmed' => '<span class="badge badge-confirmed"><i class="fas fa-check-circle me-1"></i>Confirmed</span>',
        'pending' => '<span class="badge badge-pending"><i class="fas fa-clock me-1"></i>Pending</span>',
        'cancelled' => '<span class="badge badge-cancelled"><i class="fas fa-times-circle me-1"></i>Cancelled</span>',
        'completed' => '<span class="badge badge-completed"><i class="fas fa-check-circle me-1"></i>Completed</span>',
    ];
    return $badges[$status] ?? '<span class="badge bg-secondary">' . ucfirst($status) . '</span>';
}

function getEventIcon($type) {
    $icons = [
        'birthday' => '<i class="fas fa-birthday-cake text-pink-500"></i>',
        'anniversary' => '<i class="fas fa-heart text-red-500"></i>',
        'reunion' => '<i class="fas fa-graduation-cap text-blue-500"></i>',
        'corporate' => '<i class="fas fa-briefcase text-purple-500"></i>',
        'other' => '<i class="fas fa-glass-cheers text-amber-500"></i>',
    ];
    return $icons[$type] ?? '<i class="fas fa-glass-cheers text-amber-500"></i>';
}
?>

<!-- Welcome Section -->
<div class="d-flex justify-content-between align-items-center mb-4 fade-in">
    <div>
        <h4 class="mb-1">Welcome back, Admin!</h4>
        <p class="text-muted mb-0">Here's what's happening at Cafè Erlinda today.</p>
    </div>
    <div class="btn-group">
        <button class="btn btn-outline-secondary btn-sm active">Today</button>
        <button class="btn btn-outline-secondary btn-sm">This Week</button>
        <button class="btn btn-outline-secondary btn-sm">This Month</button>
    </div>
</div>

<!-- Stats Grid -->
<div class="stats-grid fade-in">
    <div class="stat-card">
        <div class="stat-header">
            <div>
                <div class="stat-title">Total Bookings</div>
                <div class="stat-value"><?php echo $stats['total_bookings']; ?></div>
            </div>
            <div class="stat-icon blue">
                <i class="fas fa-calendar-alt"></i>
            </div>
        </div>
        <div class="stat-trend up">
            <i class="fas fa-arrow-up"></i>
            <span>+12% from last month</span>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-header">
            <div>
                <div class="stat-title">Pending Bookings</div>
                <div class="stat-value text-amber-600"><?php echo $stats['pending_bookings']; ?></div>
            </div>
            <div class="stat-icon amber">
                <i class="fas fa-clock"></i>
            </div>
        </div>
        <div class="stat-trend down">
            <i class="fas fa-arrow-down"></i>
            <span>-5% from yesterday</span>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-header">
            <div>
                <div class="stat-title">Confirmed</div>
                <div class="stat-value text-green-600"><?php echo $stats['confirmed_bookings']; ?></div>
            </div>
            <div class="stat-icon green">
                <i class="fas fa-check-circle"></i>
            </div>
        </div>
        <div class="stat-trend up">
            <i class="fas fa-arrow-up"></i>
            <span>+8% this week</span>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-header">
            <div>
                <div class="stat-title">Today's Bookings</div>
                <div class="stat-value text-teal-600"><?php echo $stats['today_bookings']; ?></div>
            </div>
            <div class="stat-icon teal">
                <i class="fas fa-users"></i>
            </div>
        </div>
        <div class="stat-trend up">
            <i class="fas fa-arrow-up"></i>
            <span>2 more expected</span>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-header">
            <div>
                <div class="stat-title">Catering Events</div>
                <div class="stat-value text-purple-600"><?php echo $stats['total_catering']; ?></div>
            </div>
            <div class="stat-icon purple">
                <i class="fas fa-glass-cheers"></i>
            </div>
        </div>
        <div class="stat-trend up">
            <i class="fas fa-arrow-up"></i>
            <span>+15% this month</span>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-header">
            <div>
                <div class="stat-title">Weekly Revenue</div>
                <div class="stat-value text-rose-600">$<?php echo number_format($stats['weekly_revenue'], 2); ?></div>
            </div>
            <div class="stat-icon rose">
                <i class="fas fa-dollar-sign"></i>
            </div>
        </div>
        <div class="stat-trend up">
            <i class="fas fa-arrow-up"></i>
            <span>+18% from last week</span>
        </div>
    </div>
</div>

<!-- Charts Row -->
<div class="row fade-in">
    <div class="col-lg-8 mb-4">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">Revenue Overview</h5>
                <span class="badge bg-success bg-opacity-10 text-success">+18% vs last week</span>
            </div>
            <div class="card-body">
                <canvas id="revenueChart" height="250"></canvas>
            </div>
        </div>
    </div>
    <div class="col-lg-4 mb-4">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Booking Status</h5>
            </div>
            <div class="card-body">
                <canvas id="statusChart" height="250"></canvas>
            </div>
        </div>
    </div>
</div>

<!-- Recent Activity Row -->
<div class="row fade-in">
    <div class="col-lg-6 mb-4">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0"><i class="fas fa-calendar-alt text-amber-500 me-2"></i>Recent Table Bookings</h5>
                <a href="table-bookings.php" class="btn btn-sm btn-outline-primary">View All</a>
            </div>
            <div class="card-body p-0">
                <div class="table-container">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Customer</th>
                                <th>Date & Time</th>
                                <th>Guests</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_bookings as $booking): ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <div class="customer-avatar">
                                            <?php echo strtoupper(substr($booking['name'], 0, 1) . substr(strstr($booking['name'], ' '), 1, 1)); ?>
                                        </div>
                                        <div>
                                            <div class="fw-semibold"><?php echo $booking['name']; ?></div>
                                            <small class="text-muted"><?php echo $booking['email']; ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div><?php echo date('M d, Y', strtotime($booking['date'])); ?></div>
                                    <small class="text-muted"><?php echo $booking['time']; ?></small>
                                </td>
                                <td><?php echo $booking['guests']; ?> guests</td>
                                <td><?php echo getStatusBadge($booking['status']); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-lg-6 mb-4">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0"><i class="fas fa-glass-cheers text-purple-500 me-2"></i>Recent Catering Requests</h5>
                <a href="catering.php" class="btn btn-sm btn-outline-primary">View All</a>
            </div>
            <div class="card-body p-0">
                <div class="table-container">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Event</th>
                                <th>Customer</th>
                                <th>Date</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_catering as $catering): ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <div class="w-10 h-10 bg-purple-100 rounded-full d-flex align-items-center justify-content-center">
                                            <?php echo getEventIcon($catering['event_type']); ?>
                                        </div>
                                        <div>
                                            <div class="fw-semibold text-capitalize"><?php echo $catering['event_type']; ?></div>
                                            <small class="text-muted"><?php echo $catering['guests']; ?> guests</small>
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo $catering['name']; ?></td>
                                <td><?php echo date('M d, Y', strtotime($catering['date'])); ?></td>
                                <td><?php echo getStatusBadge($catering['status']); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="quick-actions fade-in">
    <div class="row align-items-center">
        <div class="col-md-6">
            <h4>Quick Actions</h4>
            <p class="mb-md-0">Manage your restaurant operations efficiently</p>
        </div>
        <div class="col-md-6 text-md-end">
            <a href="table-bookings.php?action=add" class="btn btn-light me-2">
                <i class="fas fa-plus me-2"></i>New Booking
            </a>
            <a href="catering.php?action=add" class="btn btn-light me-2">
                <i class="fas fa-plus me-2"></i>New Catering
            </a>
            <a href="menu.php?action=add" class="btn btn-light">
                <i class="fas fa-plus me-2"></i>Update Menu
            </a>
        </div>
    </div>
</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Revenue Chart
const revenueCtx = document.getElementById('revenueChart').getContext('2d');
new Chart(revenueCtx, {
    type: 'line',
    data: {
        labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        datasets: [{
            label: 'Revenue ($)',
            data: [1200, 1800, 2200, 1500, 2800, 3500, 2400],
            borderColor: '#f59e0b',
            backgroundColor: 'rgba(245, 158, 11, 0.1)',
            borderWidth: 3,
            fill: true,
            tension: 0.4,
            pointBackgroundColor: '#f59e0b',
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
            pointRadius: 5
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { display: false }
        },
        scales: {
            y: {
                beginAtZero: true,
                grid: { color: '#f1f5f9' },
                ticks: {
                    callback: function(value) {
                        return '$' + value;
                    }
                }
            },
            x: {
                grid: { display: false }
            }
        }
    }
});

// Status Chart
const statusCtx = document.getElementById('statusChart').getContext('2d');
new Chart(statusCtx, {
    type: 'doughnut',
    data: {
        labels: ['Confirmed', 'Pending', 'Completed', 'Cancelled'],
        datasets: [{
            data: [127, 18, 8, 3],
            backgroundColor: ['#16a34a', '#f59e0b', '#2563eb', '#ef4444'],
            borderWidth: 0
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'bottom',
                labels: {
                    usePointStyle: true,
                    padding: 15
                }
            }
        },
        cutout: '70%'
    }
});
</script>

<?php require_once 'includes/footer.php'; ?>
