<?php
$page_title = 'Catering Reservations';
require_once 'includes/header.php';

// Mock catering data - in production, fetch from database
$catering_reservations = [
    ['id' => 1, 'name' => 'Amanda White', 'email' => 'amanda.white@email.com', 'event_type' => 'birthday', 'people' => 30, 'event_date' => '2026-03-28', 'special_request' => 'Vegetarian options needed', 'birthday_name' => 'Tom White', 'age' => 30, 'theme' => 'Superhero', 'status' => 'confirmed'],
    ['id' => 2, 'name' => 'James Thompson', 'email' => 'j.thompson@email.com', 'event_type' => 'anniversary', 'people' => 50, 'event_date' => '2026-04-05', 'special_request' => 'Live music if possible', 'couple_name' => 'James & Mary Thompson', 'years' => 25, 'status' => 'pending'],
    ['id' => 3, 'name' => 'Patricia Lee', 'email' => 'patricia.lee@email.com', 'event_type' => 'reunion', 'people' => 80, 'event_date' => '2026-04-12', 'special_request' => 'Projector needed', 'group_name' => 'Class of 2016', 'year_grad' => 2016, 'status' => 'confirmed'],
    ['id' => 4, 'name' => 'Christopher Garcia', 'email' => 'c.garcia@email.com', 'event_type' => 'corporate', 'people' => 25, 'event_date' => '2026-03-30', 'special_request' => 'Business lunch setup', 'status' => 'pending'],
    ['id' => 5, 'name' => 'Michelle Rodriguez', 'email' => 'm.rodriguez@email.com', 'event_type' => 'birthday', 'people' => 40, 'event_date' => '2026-04-08', 'special_request' => 'Kids menu required', 'birthday_name' => 'Sofia Rodriguez', 'age' => 7, 'theme' => 'Princess', 'status' => 'confirmed'],
    ['id' => 6, 'name' => 'Daniel Clark', 'email' => 'daniel.clark@email.com', 'event_type' => 'other', 'people' => 15, 'event_date' => '2026-03-25', 'special_request' => 'Private dining room', 'status' => 'completed'],
];

// Calculate stats
$stats = [
    'total' => count($catering_reservations),
    'pending' => count(array_filter($catering_reservations, fn($c) => $c['status'] === 'pending')),
    'confirmed' => count(array_filter($catering_reservations, fn($c) => $c['status'] === 'confirmed')),
    'upcoming' => count(array_filter($catering_reservations, fn($c) => $c['status'] === 'confirmed' && strtotime($c['event_date']) > time())),
];

function getStatusBadge($status) {
    $badges = [
        'confirmed' => '<span class="badge badge-confirmed"><i class="fas fa-check-circle me-1"></i>Confirmed</span>',
        'pending' => '<span class="badge badge-pending"><i class="fas fa-clock me-1"></i>Pending</span>',
        'cancelled' => '<span class="badge badge-cancelled"><i class="fas fa-times-circle me-1"></i>Cancelled</span>',
        'completed' => '<span class="badge badge-completed"><i class="fas fa-check-circle me-1"></i>Completed</span>',
    ];
    return $badges[$status] ?? '<span class="badge bg-secondary">' . ucfirst($status) . '</span>';
}

function getEventIcon($type) {
    $icons = [
        'birthday' => '<div class="w-10 h-10 bg-pink-100 rounded-full d-flex align-items-center justify-content-center"><i class="fas fa-birthday-cake text-pink-500"></i></div>',
        'anniversary' => '<div class="w-10 h-10 bg-red-100 rounded-full d-flex align-items-center justify-content-center"><i class="fas fa-heart text-red-500"></i></div>',
        'reunion' => '<div class="w-10 h-10 bg-blue-100 rounded-full d-flex align-items-center justify-content-center"><i class="fas fa-graduation-cap text-blue-500"></i></div>',
        'corporate' => '<div class="w-10 h-10 bg-purple-100 rounded-full d-flex align-items justify-content-center"><i class="fas fa-briefcase text-purple-500"></i></div>',
        'other' => '<div class="w-10 h-10 bg-amber-100 rounded-full d-flex align-items-center justify-content-center"><i class="fas fa-glass-cheers text-amber-500"></i></div>',
    ];
    return $icons[$type] ?? $icons['other'];
}

// Handle actions
if (isset($_GET['action']) && isset($_GET['id'])) {
    // In production: Update database
    header("Location: catering.php");
    exit();
}
?>

<!-- Stats Cards -->
<div class="row fade-in">
    <div class="col-md-3 mb-4">
        <div class="stat-card">
            <div class="stat-header">
                <div>
                    <div class="stat-title">Total Events</div>
                    <div class="stat-value"><?php echo $stats['total']; ?></div>
                </div>
                <div class="stat-icon purple">
                    <i class="fas fa-glass-cheers"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="stat-card">
            <div class="stat-header">
                <div>
                    <div class="stat-title">Pending</div>
                    <div class="stat-value text-amber-600"><?php echo $stats['pending']; ?></div>
                </div>
                <div class="stat-icon amber">
                    <i class="fas fa-clock"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="stat-card">
            <div class="stat-header">
                <div>
                    <div class="stat-title">Confirmed</div>
                    <div class="stat-value text-green-600"><?php echo $stats['confirmed']; ?></div>
                </div>
                <div class="stat-icon green">
                    <i class="fas fa-check-circle"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="stat-card">
            <div class="stat-header">
                <div>
                    <div class="stat-title">Upcoming</div>
                    <div class="stat-value text-blue-600"><?php echo $stats['upcoming']; ?></div>
                </div>
                <div class="stat-icon blue">
                    <i class="fas fa-calendar-alt"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Main Card -->
<div class="card fade-in">
    <div class="card-header">
        <div class="row align-items-center">
            <div class="col-md-4">
                <h5 class="card-title mb-0">Catering Reservations</h5>
            </div>
            <div class="col-md-8">
                <div class="d-flex gap-2 justify-content-md-end">
                    <div class="search-box">
                        <i class="fas fa-search"></i>
                        <input type="text" class="form-control" placeholder="Search reservations..." id="searchInput">
                    </div>
                    <select class="form-select" style="width: 140px;" id="typeFilter">
                        <option value="all">All Types</option>
                        <option value="birthday">Birthday</option>
                        <option value="anniversary">Anniversary</option>
                        <option value="reunion">Reunion</option>
                        <option value="corporate">Corporate</option>
                        <option value="other">Other</option>
                    </select>
                    <select class="form-select" style="width: 140px;" id="statusFilter">
                        <option value="all">All Status</option>
                        <option value="pending">Pending</option>
                        <option value="confirmed">Confirmed</option>
                        <option value="completed">Completed</option>
                    </select>
                    <button class="btn btn-outline-secondary">
                        <i class="fas fa-download"></i>
                    </button>
                    <button class="btn btn-primary" style="background: linear-gradient(135deg, #9333ea 0%, #c026d3 100%); border: none;" data-bs-toggle="modal" data-bs-target="#addCateringModal">
                        <i class="fas fa-plus me-2"></i>Add Event
                    </button>
                </div>
            </div>
        </div>
    </div>
    <div class="card-body p-0">
        <div class="table-container">
            <table class="table" id="cateringTable">
                <thead>
                    <tr>
                        <th>Event</th>
                        <th>Customer</th>
                        <th>Event Date</th>
                        <th>Guests</th>
                        <th>Status</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($catering_reservations as $reservation): ?>
                    <tr data-type="<?php echo $reservation['event_type']; ?>" data-status="<?php echo $reservation['status']; ?>">
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <?php echo getEventIcon($reservation['event_type']); ?>
                                <div>
                                    <div class="fw-semibold text-capitalize"><?php echo $reservation['event_type']; ?></div>
                                    <?php if ($reservation['cbirthday_name']): ?>
                                        <small class="text-muted">For: <?php echo $reservation['cbirthday_name']; ?></small>
                                    <?php elseif ($reservation['couple_name']): ?>
                                        <small class="text-muted"><?php echo $reservation['couple_name']; ?></small>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="fw-semibold"><?php echo $reservation['name']; ?></div>
                            <small class="text-muted"><?php echo $reservation['email']; ?></small>
                        </td>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <i class="fas fa-calendar text-muted"></i>
                                <span><?php echo date('M d, Y', strtotime($reservation['event_date'])); ?></span>
                            </div>
                        </td>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <i class="fas fa-users text-muted"></i>
                                <span><?php echo $reservation['people']; ?> guests</span>
                            </div>
                        </td>
                        <td><?php echo getStatusBadge($reservation['status']); ?></td>
                        <td class="text-end">
                            <div class="dropdown">
                                <button class="btn-action" data-bs-toggle="dropdown">
                                    <i class="fas fa-ellipsis-v"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li>
                                        <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#viewModal<?php echo $reservation['id']; ?>">
                                            <i class="fas fa-eye me-2 text-primary"></i>View Details
                                        </a>
                                    </li>
                                    <?php if ($reservation['status'] === 'pending'): ?>
                                    <li>
                                        <a class="dropdown-item" href="?action=confirm&id=<?php echo $reservation['id']; ?>">
                                            <i class="fas fa-check-circle me-2 text-success"></i>Confirm
                                        </a>
                                    </li>
                                    <?php endif; ?>
                                    <?php if ($reservation['status'] !== 'cancelled' && $reservation['status'] !== 'completed'): ?>
                                    <li>
                                        <a class="dropdown-item" href="?action=cancel&id=<?php echo $reservation['id']; ?>">
                                            <i class="fas fa-times-circle me-2 text-danger"></i>Cancel
                                        </a>
                                    </li>
                                    <?php endif; ?>
                                    <li><hr class="dropdown-divider"></li>
                                    <li>
                                        <a class="dropdown-item text-danger" href="?action=delete&id=<?php echo $reservation['id']; ?>" onclick="return confirm('Are you sure?')">
                                            <i class="fas fa-trash me-2"></i>Delete
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </td>
                    </tr>
                    
                    <!-- View Modal -->
                    <div class="modal fade" id="viewModal<?php echo $reservation['id']; ?>" tabindex="-1">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title d-flex align-items-center gap-2">
                                        <?php echo getEventIcon($reservation['event_type']); ?>
                                        Event Details
                                    </h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="d-flex align-items-center gap-3 mb-4">
                                        <?php echo getEventIcon($reservation['event_type']); ?>
                                        <div>
                                            <h5 class="mb-1 text-capitalize"><?php echo $reservation['event_type']; ?> Party</h5>
                                            <p class="text-muted mb-0"><?php echo $reservation['people']; ?> guests</p>
                                        </div>
                                    </div>
                                    
                                    <div class="row g-3 mb-3">
                                        <div class="col-6">
                                            <div class="p-3 bg-light rounded">
                                                <small class="text-muted">Customer</small>
                                                <p class="mb-0 fw-semibold"><?php echo $reservation['name']; ?></p>
                                                <small class="text-muted"><?php echo $reservation['email']; ?></small>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="p-3 bg-light rounded">
                                                <small class="text-muted">Event Date</small>
                                                <p class="mb-0 fw-semibold"><?php echo date('M d, Y', strtotime($reservation['event_date'])); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <?php if ($reservation['event_type'] === 'birthday' && $reservation['birthday_name']): ?>
                                    <div class="p-3 bg-pink-50 rounded border border-pink-100 mb-3" style="background: #fdf2f8;">
                                        <small class="text-pink-600 fw-semibold"><i class="fas fa-birthday-cake me-2"></i>Birthday Details</small>
                                        <p class="mb-1 mt-2">Celebrating: <strong><?php echo $reservation['birthday_name']; ?></strong></p>
                                        <?php if ($reservation['age']): ?><p class="mb-1">Age turning: <strong><?php echo $reservation['age']; ?></strong></p><?php endif; ?>
                                        <?php if ($reservation['theme']): ?><p class="mb-0">Theme: <strong><?php echo $reservation['theme']; ?></strong></p><?php endif; ?>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <?php if ($reservation['event_type'] === 'anniversary' && $reservation['couple_name']): ?>
                                    <div class="p-3 bg-red-50 rounded border border-red-100 mb-3" style="background: #fef2f2;">
                                        <small class="text-red-600 fw-semibold"><i class="fas fa-heart me-2"></i>Anniversary Details</small>
                                        <p class="mb-1 mt-2">Couple: <strong><?php echo $reservation['couple_name']; ?></strong></p>
                                        <?php if ($reservation['years']): ?><p class="mb-0">Years together: <strong><?php echo $reservation['years']; ?></strong></p><?php endif; ?>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <?php if ($reservation['event_type'] === 'reunion' && $reservation['group_name']): ?>
                                    <div class="p-3 bg-blue-50 rounded border border-blue-100 mb-3" style="background: #eff6ff;">
                                        <small class="text-blue-600 fw-semibold"><i class="fas fa-graduation-cap me-2"></i>Reunion Details</small>
                                        <p class="mb-1 mt-2">Group: <strong><?php echo $reservation['group_name']; ?></strong></p>
                                        <?php if ($reservation['year_grad']): ?><p class="mb-0">Graduation Year: <strong><?php echo $reservation['year_grad']; ?></strong></p><?php endif; ?>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <?php if ($reservation['special_request']): ?>
                                    <div class="p-3 bg-light rounded">
                                        <small class="text-muted"><i class="fas fa-comment me-2"></i>Special Request</small>
                                        <p class="mb-0 mt-1"><?php echo $reservation['special_request']; ?></p>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <div class="mt-3 d-flex justify-content-between align-items-center">
                                        <span class="text-muted">Status</span>
                                        <?php echo getStatusBadge($reservation['status']); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Catering Modal -->
<div class="modal fade" id="addCateringModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Catering Reservation</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Customer Name</label>
                            <input type="text" name="name" class="form-control" placeholder="Full name" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control" placeholder="email@example.com" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Event Type</label>
                            <select name="event_type" class="form-select" required>
                                <option value="birthday">Birthday</option>
                                <option value="anniversary">Anniversary</option>
                                <option value="reunion">Reunion</option>
                                <option value="corporate">Corporate</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Number of Guests</label>
                            <input type="number" name="people" class="form-control" min="1" placeholder="30" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Event Date</label>
                            <input type="date" name="event_date" class="form-control" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Special Request</label>
                            <textarea name="special_request" class="form-control" rows="3" placeholder="Any special requirements..."></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" style="background: linear-gradient(135deg, #9333ea 0%, #c026d3 100%); border: none;">Create Reservation</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Search functionality
document.getElementById('searchInput').addEventListener('input', function() {
    const searchTerm = this.value.toLowerCase();
    const rows = document.querySelectorAll('#cateringTable tbody tr');
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(searchTerm) ? '' : 'none';
    });
});

// Type filter
document.getElementById('typeFilter').addEventListener('change', filterTable);

// Status filter
document.getElementById('statusFilter').addEventListener('change', filterTable);

function filterTable() {
    const type = document.getElementById('typeFilter').value;
    const status = document.getElementById('statusFilter').value;
    const rows = document.querySelectorAll('#cateringTable tbody tr');
    
    rows.forEach(row => {
        const matchType = type === 'all' || row.dataset.type === type;
        const matchStatus = status === 'all' || row.dataset.status === status;
        row.style.display = (matchType && matchStatus) ? '' : 'none';
    });
}
</script>

<?php require_once 'includes/footer.php'; ?>
