<?php
$conn=mysqli_connect("localhost","root","","cafe_erlinda");
if(!$conn){
	("Connection Failed:" . mysqli_connect_error());
}
?>