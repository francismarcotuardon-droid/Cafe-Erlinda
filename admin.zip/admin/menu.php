<?php
$page_title = 'Menu Management';
require_once 'includes/header.php';

// Mock menu items - in production, fetch from database
$menu_items = [
    ['id' => 1, 'name' => 'Classic Chicken Burger', 'description' => 'Juicy grilled chicken patty with fresh lettuce, tomato, and special sauce', 'price' => 12.99, 'category' => 'lunch', 'is_available' => true, 'is_popular' => true],
    ['id' => 2, 'name' => 'Margherita Pizza', 'description' => 'Fresh mozzarella, tomato sauce, and basil on thin crust', 'price' => 14.99, 'category' => 'lunch', 'is_available' => true, 'is_popular' => true],
    ['id' => 3, 'name' => 'Grilled Salmon', 'description' => 'Fresh Atlantic salmon with lemon butter sauce and seasonal vegetables', 'price' => 24.99, 'category' => 'dinner', 'is_available' => true, 'is_popular' => false],
    ['id' => 4, 'name' => 'Caesar Salad', 'description' => 'Crisp romaine lettuce, parmesan cheese, croutons, and Caesar dressing', 'price' => 10.99, 'category' => 'lunch', 'is_available' => true, 'is_popular' => false],
    ['id' => 5, 'name' => 'Eggs Benedict', 'description' => 'Poached eggs on English muffin with hollandaise sauce and Canadian bacon', 'price' => 13.99, 'category' => 'breakfast', 'is_available' => true, 'is_popular' => true],
    ['id' => 6, 'name' => 'Pancake Stack', 'description' => 'Fluffy pancakes with maple syrup and fresh berries', 'price' => 9.99, 'category' => 'breakfast', 'is_available' => true, 'is_popular' => false],
    ['id' => 7, 'name' => 'Ribeye Steak', 'description' => '12oz prime ribeye with garlic mashed potatoes and asparagus', 'price' => 34.99, 'category' => 'dinner', 'is_available' => true, 'is_popular' => true],
    ['id' => 8, 'name' => 'Chocolate Lava Cake', 'description' => 'Warm chocolate cake with molten center and vanilla ice cream', 'price' => 8.99, 'category' => 'dessert', 'is_available' => true, 'is_popular' => true],
    ['id' => 9, 'name' => 'Fresh Fruit Smoothie', 'description' => 'Blend of seasonal fruits with yogurt and honey', 'price' => 6.99, 'category' => 'beverage', 'is_available' => true, 'is_popular' => false],
    ['id' => 10, 'name' => 'Iced Caramel Latte', 'description' => 'Espresso with caramel syrup and cold milk over ice', 'price' => 5.99, 'category' => 'beverage', 'is_available' => true, 'is_popular' => true],
];

// Calculate stats
$stats = [
    'total' => count($menu_items),
    'available' => count(array_filter($menu_items, fn($m) => $m['is_available'])),
    'popular' => count(array_filter($menu_items, fn($m) => $m['is_popular'])),
    'categories' => count(array_unique(array_column($menu_items, 'category'))),
];

function getCategoryIcon($category) {
    $icons = [
        'breakfast' => '<i class="fas fa-coffee text-amber-500"></i>',
        'lunch' => '<i class="fas fa-sun text-yellow-500"></i>',
        'dinner' => '<i class="fas fa-moon text-indigo-500"></i>',
        'beverage' => '<i class="fas fa-glass-water text-blue-500"></i>',
        'dessert' => '<i class="fas fa-ice-cream text-pink-500"></i>',
    ];
    return $icons[$category] ?? '<i class="fas fa-utensils text-gray-500"></i>';
}

function getCategoryBadge($category) {
    $badges = [
        'breakfast' => 'bg-amber-100 text-amber-700',
        'lunch' => 'bg-yellow-100 text-yellow-700',
        'dinner' => 'bg-indigo-100 text-indigo-700',
        'beverage' => 'bg-blue-100 text-blue-700',
        'dessert' => 'bg-pink-100 text-pink-700',
    ];
    $class = $badges[$category] ?? 'bg-gray-100 text-gray-700';
    return '<span class="badge ' . $class . ' text-capitalize">' . $category . '</span>';
}

// Handle actions
if (isset($_GET['action']) && isset($_GET['id'])) {
    // In production: Update database
    header("Location: menu.php");
    exit();
}
?>

<!-- Stats Cards -->
<div class="row fade-in">
    <div class="col-md-3 mb-4">
        <div class="stat-card">
            <div class="stat-header">
                <div>
                    <div class="stat-title">Total Items</div>
                    <div class="stat-value"><?php echo $stats['total']; ?></div>
                </div>
                <div class="stat-icon amber">
                    <i class="fas fa-utensils"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="stat-card">
            <div class="stat-header">
                <div>
                    <div class="stat-title">Available</div>
                    <div class="stat-value text-green-600"><?php echo $stats['available']; ?></div>
                </div>
                <div class="stat-icon green">
                    <i class="fas fa-check-circle"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="stat-card">
            <div class="stat-header">
                <div>
                    <div class="stat-title">Popular Items</div>
                    <div class="stat-value text-amber-600"><?php echo $stats['popular']; ?></div>
                </div>
                <div class="stat-icon amber">
                    <i class="fas fa-star"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="stat-card">
            <div class="stat-header">
                <div>
                    <div class="stat-title">Categories</div>
                    <div class="stat-value text-purple-600"><?php echo $stats['categories']; ?></div>
                </div>
                <div class="stat-icon purple">
                    <i class="fas fa-filter"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Main Card -->
<div class="card fade-in">
    <div class="card-header">
        <div class="row align-items-center">
            <div class="col-md-4">
                <h5 class="card-title mb-0">Menu Items</h5>
            </div>
            <div class="col-md-8">
                <div class="d-flex gap-2 justify-content-md-end">
                    <div class="search-box">
                        <i class="fas fa-search"></i>
                        <input type="text" class="form-control" placeholder="Search menu..." id="searchInput">
                    </div>
                    <select class="form-select" style="width: 160px;" id="categoryFilter">
                        <option value="all">All Categories</option>
                        <option value="breakfast">Breakfast</option>
                        <option value="lunch">Lunch</option>
                        <option value="dinner">Dinner</option>
                        <option value="beverage">Beverages</option>
                        <option value="dessert">Desserts</option>
                    </select>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addItemModal">
                        <i class="fas fa-plus me-2"></i>Add Item
                    </button>
                </div>
            </div>
        </div>
    </div>
    <div class="card-body p-0">
        <div class="table-container">
            <table class="table" id="menuTable">
                <thead>
                    <tr>
                        <th>Item</th>
                        <th>Category</th>
                        <th>Price</th>
                        <th>Available</th>
                        <th>Popular</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($menu_items as $item): ?>
                    <tr data-category="<?php echo $item['category']; ?>">
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <div class="w-12 h-12 bg-amber-100 rounded-lg d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                                    <?php echo getCategoryIcon($item['category']); ?>
                                </div>
                                <div>
                                    <div class="fw-semibold"><?php echo $item['name']; ?></div>
                                    <small class="text-muted"><?php echo substr($item['description'], 0, 50) . '...'; ?></small>
                                </div>
                            </div>
                        </td>
                        <td><?php echo getCategoryBadge($item['category']); ?></td>
                        <td>
                            <div class="d-flex align-items-center gap-1">
                                <i class="fas fa-dollar-sign text-muted"></i>
                                <span class="fw-semibold"><?php echo number_format($item['price'], 2); ?></span>
                            </div>
                        </td>
                        <td>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" <?php echo $item['is_available'] ? 'checked' : ''; ?> 
                                    onchange="window.location.href='?action=toggle_available&id=<?php echo $item['id']; ?>'">
                                <label class="form-check-label <?php echo $item['is_available'] ? 'text-green-600' : 'text-muted'; ?>">
                                    <?php echo $item['is_available'] ? 'Available' : 'Unavailable'; ?>
                                </label>
                            </div>
                        </td>
                        <td>
                            <a href="?action=toggle_popular&id=<?php echo $item['id']; ?>" class="btn-action <?php echo $item['is_popular'] ? 'text-amber-500' : 'text-muted'; ?>">
                                <i class="fas fa-star <?php echo $item['is_popular'] ? '' : 'far'; ?>" style="font-size: 20px;"></i>
                            </a>
                        </td>
                        <td class="text-end">
                            <div class="dropdown">
                                <button class="btn-action" data-bs-toggle="dropdown">
                                    <i class="fas fa-ellipsis-v"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li>
                                        <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#viewModal<?php echo $item['id']; ?>">
                                            <i class="fas fa-eye me-2 text-primary"></i>View Details
                                        </a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#editModal<?php echo $item['id']; ?>">
                                            <i class="fas fa-edit me-2 text-success"></i>Edit
                                        </a>
                                    </li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li>
                                        <a class="dropdown-item text-danger" href="?action=delete&id=<?php echo $item['id']; ?>" onclick="return confirm('Are you sure you want to delete this item?')">
                                            <i class="fas fa-trash me-2"></i>Delete
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </td>
                    </tr>
                    
                    <!-- View Modal -->
                    <div class="modal fade" id="viewModal<?php echo $item['id']; ?>" tabindex="-1">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title d-flex align-items-center gap-2">
                                        <?php echo getCategoryIcon($item['category']); ?>
                                        Menu Item Details
                                    </h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="d-flex align-items-center gap-3 mb-4">
                                        <div class="w-16 h-16 bg-amber-100 rounded-xl d-flex align-items-center justify-content-center" style="width: 80px; height: 80px;">
                                            <?php echo getCategoryIcon($item['category']); ?>
                                        </div>
                                        <div>
                                            <h5 class="mb-1"><?php echo $item['name']; ?></h5>
                                            <?php echo getCategoryBadge($item['category']); ?>
                                        </div>
                                    </div>
                                    
                                    <div class="p-3 bg-light rounded mb-3">
                                        <small class="text-muted">Description</small>
                                        <p class="mb-0 mt-1"><?php echo $item['description']; ?></p>
                                    </div>
                                    
                                    <div class="row g-3">
                                        <div class="col-6">
                                            <div class="p-3 bg-light rounded">
                                                <small class="text-muted">Price</small>
                                                <p class="mb-0 fw-semibold text-green-600" style="font-size: 20px;">$<?php echo number_format($item['price'], 2); ?></p>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="p-3 bg-light rounded">
                                                <small class="text-muted">Status</small>
                                                <div class="d-flex align-items-center gap-2 mt-1">
                                                    <div class="w-2 h-2 rounded-circle <?php echo $item['is_available'] ? 'bg-green-500' : 'bg-red-500'; ?>" style="width: 10px; height: 10px;"></div>
                                                    <span class="fw-semibold"><?php echo $item['is_available'] ? 'Available' : 'Unavailable'; ?></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="mt-3 d-flex align-items-center gap-2">
                                        <i class="fas fa-star <?php echo $item['is_popular'] ? 'text-amber-500' : 'text-gray-300'; ?>"></i>
                                        <span><?php echo $item['is_popular'] ? 'Popular Item' : 'Not marked as popular'; ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Edit Modal -->
                    <div class="modal fade" id="editModal<?php echo $item['id']; ?>" tabindex="-1">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Edit Menu Item</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <form method="POST" action="">
                                    <div class="modal-body">
                                        <div class="mb-3">
                                            <label class="form-label">Item Name</label>
                                            <input type="text" name="name" class="form-control" value="<?php echo $item['name']; ?>" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Description</label>
                                            <textarea name="description" class="form-control" rows="3" required><?php echo $item['description']; ?></textarea>
                                        </div>
                                        <div class="row g-3">
                                            <div class="col-md-6">
                                                <label class="form-label">Category</label>
                                                <select name="category" class="form-select" required>
                                                    <option value="breakfast" <?php echo $item['category'] === 'breakfast' ? 'selected' : ''; ?>>Breakfast</option>
                                                    <option value="lunch" <?php echo $item['category'] === 'lunch' ? 'selected' : ''; ?>>Lunch</option>
                                                    <option value="dinner" <?php echo $item['category'] === 'dinner' ? 'selected' : ''; ?>>Dinner</option>
                                                    <option value="beverage" <?php echo $item['category'] === 'beverage' ? 'selected' : ''; ?>>Beverage</option>
                                                    <option value="dessert" <?php echo $item['category'] === 'dessert' ? 'selected' : ''; ?>>Dessert</option>
                                                </select>
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label">Price ($)</label>
                                                <input type="number" name="price" class="form-control" step="0.01" value="<?php echo $item['price']; ?>" required>
                                            </div>
                                        </div>
                                        <div class="mt-3 d-flex gap-4">
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="is_available" id="available<?php echo $item['id']; ?>" <?php echo $item['is_available'] ? 'checked' : ''; ?>>
                                                <label class="form-check-label" for="available<?php echo $item['id']; ?>">Available</label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="is_popular" id="popular<?php echo $item['id']; ?>" <?php echo $item['is_popular'] ? 'checked' : ''; ?>>
                                                <label class="form-check-label" for="popular<?php echo $item['id']; ?>">Mark as Popular</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-primary">Save Changes</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Item Modal -->
<div class="modal fade" id="addItemModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Menu Item</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Item Name</label>
                        <input type="text" name="name" class="form-control" placeholder="e.g., Grilled Salmon" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea name="description" class="form-control" rows="3" placeholder="Describe the dish..." required></textarea>
                    </div>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Category</label>
                            <select name="category" class="form-select" required>
                                <option value="breakfast">Breakfast</option>
                                <option value="lunch">Lunch</option>
                                <option value="dinner">Dinner</option>
                                <option value="beverage">Beverage</option>
                                <option value="dessert">Dessert</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Price ($)</label>
                            <input type="number" name="price" class="form-control" step="0.01" placeholder="0.00" required>
                        </div>
                    </div>
                    <div class="mb-3 mt-3">
                        <label class="form-label">Image URL</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-image"></i></span>
                            <input type="text" name="image" class="form-control" placeholder="/img/menu-item.jpg">
                        </div>
                    </div>
                    <div class="d-flex gap-4">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="is_available" checked>
                            <label class="form-check-label">Available</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="is_popular">
                            <label class="form-check-label">Mark as Popular</label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Add Item</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// Search functionality
document.getElementById('searchInput').addEventListener('input', function() {
    const searchTerm = this.value.toLowerCase();
    const rows = document.querySelectorAll('#menuTable tbody tr');
    
    rows.forEach(row => {
        if (row.dataset.category) {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(searchTerm) ? '' : 'none';
        }
    });
});

// Category filter
document.getElementById('categoryFilter').addEventListener('change', function() {
    const category = this.value;
    const rows = document.querySelectorAll('#menuTable tbody tr');
    
    rows.forEach(row => {
        if (row.dataset.category) {
            if (category === 'all' || row.dataset.category === category) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        }
    });
});
</script>

<?php require_once 'includes/footer.php'; ?>
