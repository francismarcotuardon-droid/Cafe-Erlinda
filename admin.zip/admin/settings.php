<?php
$page_title = 'Settings';
require_once 'includes/header.php';

$restaurant_info = [
    'name' => 'Cafè Erlinda',
    'email' => 'info@caferlinda.com',
    'phone' => '+012 345 67890',
    'address' => '123 Street, New York, USA',
    'opening_hours' => [
        'monday' => '09:00 - 21:00',
        'tuesday' => '09:00 - 21:00',
        'wednesday' => '09:00 - 21:00',
        'thursday' => '09:00 - 21:00',
        'friday' => '09:00 - 21:00',
        'saturday' => '09:00 - 21:00',
        'sunday' => '10:00 - 20:00',
    ]
];
?>

<div class="fade-in">
    <div class="mb-4">
        <h4>Settings</h4>
        <p class="text-muted">Manage your restaurant and account settings</p>
    </div>

    <ul class="nav nav-tabs mb-4" id="settingsTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab">
                <i class="fas fa-user me-2"></i>Profile
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="restaurant-tab" data-bs-toggle="tab" data-bs-target="#restaurant" type="button" role="tab">
                <i class="fas fa-store me-2"></i>Restaurant
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="notifications-tab" data-bs-toggle="tab" data-bs-target="#notifications" type="button" role="tab">
                <i class="fas fa-bell me-2"></i>Notifications
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="security-tab" data-bs-toggle="tab" data-bs-target="#security" type="button" role="tab">
                <i class="fas fa-shield-alt me-2"></i>Security
            </button>
        </li>
    </ul>

    <div class="tab-content" id="settingsTabsContent">
        <!-- Profile Tab -->
        <div class="tab-pane fade show active" id="profile" role="tabpanel">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Profile Information</h5>
                </div>
                <div class="card-body">
                    <div class="d-flex align-items-center gap-4 mb-4">
                        <div class="position-relative">
                            <div class="user-avatar" style="width: 80px; height: 80px; font-size: 28px;">AD</div>
                            <button class="btn btn-sm btn-primary position-absolute" style="bottom: -5px; right: -5px; border-radius: 50%; width: 32px; height: 32px; padding: 0;">
                                <i class="fas fa-camera"></i>
                            </button>
                        </div>
                        <div>
                            <h5 class="mb-1">Admin User</h5>
                            <p class="text-muted mb-0">Administrator</p>
                            <p class="text-muted mb-0">admin@caferlinda.com</p>
                        </div>
                    </div>

                    <hr class="my-4">

                    <form method="POST" action="">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">First Name</label>
                                <input type="text" class="form-control" value="Admin">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Last Name</label>
                                <input type="text" class="form-control" value="User">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Email</label>
                                <input type="email" class="form-control" value="admin@caferlinda.com">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Phone</label>
                                <input type="tel" class="form-control" value="+012 345 67890">
                            </div>
                        </div>
                        <div class="mt-4 text-end">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>Save Changes
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Restaurant Tab -->
        <div class="tab-pane fade" id="restaurant" role="tabpanel">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0"><i class="fas fa-utensils text-amber-500 me-2"></i>Restaurant Information</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Restaurant Name</label>
                                <input type="text" class="form-control" value="<?php echo $restaurant_info['name']; ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Email Address</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                    <input type="email" class="form-control" value="<?php echo $restaurant_info['email']; ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Phone Number</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-phone"></i></span>
                                    <input type="tel" class="form-control" value="<?php echo $restaurant_info['phone']; ?>">
                                </div>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Address</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-map-marker-alt"></i></span>
                                    <input type="text" class="form-control" value="<?php echo $restaurant_info['address']; ?>">
                                </div>
                            </div>
                        </div>

                        <hr class="my-4">

                        <h6 class="mb-3"><i class="fas fa-clock text-amber-500 me-2"></i>Opening Hours</h6>
                        <div class="row g-3">
                            <?php foreach ($restaurant_info['opening_hours'] as $day => $hours): ?>
                            <div class="col-md-6">
                                <div class="d-flex align-items-center justify-content-between p-3 bg-light rounded">
                                    <span class="text-capitalize fw-semibold"><?php echo $day; ?></span>
                                    <input type="text" class="form-control" style="width: 150px; text-align: right;" value="<?php echo $hours; ?>">
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>

                        <div class="mt-4 text-end">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>Save Changes
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Notifications Tab -->
        <div class="tab-pane fade" id="notifications" role="tabpanel">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Notification Preferences</h5>
                </div>
                <div class="card-body">
                    <div class="mb-4 p-3 bg-light rounded d-flex align-items-center justify-content-between">
                        <div>
                            <p class="fw-semibold mb-1">Email Notifications</p>
                            <p class="text-muted mb-0">Receive notifications via email</p>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" checked style="width: 50px; height: 25px;">
                        </div>
                    </div>

                    <div class="mb-4 p-3 bg-light rounded d-flex align-items-center justify-content-between">
                        <div>
                            <p class="fw-semibold mb-1">New Booking Alerts</p>
                            <p class="text-muted mb-0">Get notified when a new table is booked</p>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" checked style="width: 50px; height: 25px;">
                        </div>
                    </div>

                    <div class="mb-4 p-3 bg-light rounded d-flex align-items-center justify-content-between">
                        <div>
                            <p class="fw-semibold mb-1">Catering Request Alerts</p>
                            <p class="text-muted mb-0">Get notified for new catering requests</p>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" checked style="width: 50px; height: 25px;">
                        </div>
                    </div>

                    <div class="mb-4 p-3 bg-light rounded d-flex align-items-center justify-content-between">
                        <div>
                            <p class="fw-semibold mb-1">Daily Summary</p>
                            <p class="text-muted mb-0">Receive a daily summary of activities</p>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" checked style="width: 50px; height: 25px;">
                        </div>
                    </div>

                    <div class="mb-4 p-3 bg-light rounded d-flex align-items-center justify-content-between">
                        <div>
                            <p class="fw-semibold mb-1">Marketing Emails</p>
                            <p class="text-muted mb-0">Receive promotional emails and updates</p>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" style="width: 50px; height: 25px;">
                        </div>
                    </div>

                    <div class="text-end">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>Save Preferences
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Security Tab -->
        <div class="tab-pane fade" id="security" role="tabpanel">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">Change Password</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label class="form-label">Current Password</label>
                            <input type="password" class="form-control" placeholder="Enter current password">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">New Password</label>
                            <input type="password" class="form-control" placeholder="Enter new password">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Confirm New Password</label>
                            <input type="password" class="form-control" placeholder="Confirm new password">
                        </div>
                        <div class="text-end">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-key me-2"></i>Update Password
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">Two-Factor Authentication</h5>
                </div>
                <div class="card-body">
                    <div class="p-3 bg-light rounded d-flex align-items-center justify-content-between">
                        <div>
                            <p class="fw-semibold mb-1">Enable 2FA</p>
                            <p class="text-muted mb-0">Require a verification code when logging in</p>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" style="width: 50px; height: 25px;">
                        </div>
                    </div>
                </div>
            </div>

            <div class="card border-danger">
                <div class="card-header bg-danger text-white">
                    <h5 class="card-title mb-0"><i class="fas fa-exclamation-triangle me-2"></i>Danger Zone</h5>
                </div>
                <div class="card-body">
                    <div class="p-3 bg-danger bg-opacity-10 rounded border border-danger d-flex align-items-center justify-content-between">
                        <div>
                            <p class="fw-semibold text-danger mb-1">Delete Account</p>
                            <p class="text-muted mb-0">This action cannot be undone</p>
                        </div>
                        <button class="btn btn-danger" onclick="return confirm('Are you sure you want to delete your account? This cannot be undone.')">
                            <i class="fas fa-trash me-2"></i>Delete Account
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
