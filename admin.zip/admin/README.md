# Cafè Erlinda Admin Dashboard

A comprehensive PHP-based admin dashboard for managing the Cafè Erlinda restaurant website.

## 📁 File Structure

```
admin/
├── includes/
│   ├── db_connect.php      # Database connection (shared with main site)
│   ├── session.php         # Session management functions
│   ├── header.php          # Admin header with sidebar navigation
│   └── footer.php          # Admin footer with scripts
├── css/
│   └── admin-style.css     # Admin dashboard styles
├── login.php               # Admin login page
├── logout.php              # Logout handler
├── index.php               # Dashboard overview
├── table-bookings.php      # Table bookings management
├── catering.php            # Catering reservations management
├── menu.php                # Menu management
├── settings.php            # Settings page
└── README.md               # This file
```

## 🔑 Login Credentials

- **Username:** `admin`
- **Password:** `admin123`

## 🚀 Features

### Dashboard Overview
- Statistics cards showing key metrics
- Revenue and booking charts
- Recent activity feeds
- Quick action buttons

### Table Bookings Management
- View all table reservations
- Filter by status (Pending, Confirmed, Cancelled, Completed)
- Search by customer name, email, or table number
- Confirm, cancel, or delete bookings
- Add new bookings manually
- View detailed booking information

### Catering Reservations
- Manage event bookings (Birthday, Anniversary, Reunion, Corporate, Other)
- Event-specific details display
- Filter by event type and status
- Confirm or cancel reservations
- Add new catering events

### Menu Management
- Full menu item control
- Toggle item availability
- Mark items as popular
- Filter by category
- Add, edit, and delete menu items

### Settings
- Profile management
- Restaurant information
- Opening hours configuration
- Notification preferences
- Password change
- Two-factor authentication

## 🔧 Integration with Main Site

The admin panel shares the database connection with your main website. To fully integrate:

1. Copy the `admin/` folder to your website root directory
2. Ensure the database connection in `includes/db_connect.php` matches your main site
3. Access the admin panel at `https://yoursite.com/admin/`

## 📝 Database Integration

The admin panel is designed to work with these database tables:
- `table_form` - Table bookings
- `reservations` - Catering reservations
- `menu_items` - Menu items (you may need to create this table)

Example SQL for menu_items table:
```sql
CREATE TABLE menu_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    category ENUM('breakfast', 'lunch', 'dinner', 'beverage', 'dessert') NOT NULL,
    image VARCHAR(255),
    is_available BOOLEAN DEFAULT TRUE,
    is_popular BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## 🎨 Customization

The admin panel uses a warm amber/orange color scheme that matches the Cafè Erlinda brand. You can customize colors in `css/admin-style.css` by modifying the CSS variables at the top of the file.

## 📱 Responsive Design

The admin dashboard is fully responsive and works on:
- Desktop computers
- Tablets
- Mobile devices

## 🔒 Security Notes

- Always use HTTPS in production
- Change the default admin credentials
- Implement proper password hashing for production use
- Add CSRF protection for forms
- Implement rate limiting for login attempts
