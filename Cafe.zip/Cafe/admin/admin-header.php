<?php
require_once 'session.php';
require_once '../conn.php';
requireLogin();

// Get current page for active menu
$current_page = basename($_SERVER['PHP_SELF'], '.php');

// Fetch admin info
$admin_name = $_SESSION['admin_name'] ?? 'Admin';
$admin_role = $_SESSION['admin_role'] ?? 'Administrator';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? 'Dashboard'; ?> - Cafè Erlinda Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #f59e0b;
            --primary-dark: #d97706;
            --secondary: #1e293b;
            --success: #16a34a;
            --warning: #f59e0b;
            --danger: #ef4444;
            --info: #2563eb;
        }

        body {
            background: #f8fafc;
            font-family: 'Segoe UI', system-ui, sans-serif;
        }

        .sidebar {
            background: white;
            min-height: 100vh;
            border-right: 1px solid #e5e7eb;
            position: fixed;
            width: 260px;
            z-index: 1000;
        }

        .sidebar-brand {
            padding: 20px;
            border-bottom: 1px solid #e5e7eb;
        }

        .sidebar-brand h4 {
            color: var(--primary);
            margin: 0;
            font-weight: 700;
        }

        .nav-menu {
            padding: 20px 0;
        }

        .nav-item {
            margin: 4px 16px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            color: #64748b;
            text-decoration: none;
            border-radius: 10px;
            transition: all 0.3s;
        }

        .nav-link:hover, .nav-link.active {
            background: #fef3c7;
            color: var(--primary);
        }

        .nav-link i {
            width: 20px;
            text-align: center;
        }

        .main-content {
            margin-left: 260px;
            padding: 24px;
        }

        .topbar {
            background: white;
            padding: 16px 24px;
            border-radius: 16px;
            margin-bottom: 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }

        .stat-card {
            background: white;
            border-radius: 16px;
            padding: 24px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            height: 100%;
        }

        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }

        .stat-title {
            color: #64748b;
            font-size: 14px;
            font-weight: 500;
        }

        .stat-value {
            font-size: 32px;
            font-weight: 700;
            color: #1e293b;
            margin-top: 8px;
        }

        .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }

        .stat-icon.blue { background: #dbeafe; color: #2563eb; }
        .stat-icon.green { background: #dcfce7; color: #16a34a; }
        .stat-icon.amber { background: #fef3c7; color: #f59e0b; }
        .stat-icon.purple { background: #f3e8ff; color: #9333ea; }
        .stat-icon.red { background: #fee2e2; color: #ef4444; }
        .stat-icon.rose { background: #ffe4e6; color: #e11d48; }
        .stat-icon.teal { background: #ccfbf1; color: #0d9488; }

        .card {
            background: white;
            border-radius: 16px;
            border: none;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }

        .card-header {
            padding: 20px 24px;
            border-bottom: 1px solid #e5e7eb;
            background: transparent;
        }

        .card-title {
            font-weight: 600;
            color: #1e293b;
        }

        .table-container {
            overflow-x: auto;
        }

        .table {
            margin: 0;
        }

        .table th {
            font-weight: 600;
            color: #64748b;
            border-bottom: 2px solid #e5e7eb;
            padding: 16px;
        }

        .table td {
            padding: 16px;
            vertical-align: middle;
        }

        .badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-weight: 500;
            font-size: 12px;
        }

        .badge-confirmed { background: #dcfce7; color: #16a34a; }
        .badge-pending { background: #fef3c7; color: #d97706; }
        .badge-cancelled { background: #fee2e2; color: #ef4444; }
        .badge-completed { background: #dbeafe; color: #2563eb; }

        .btn-action {
            background: none;
            border: none;
            color: #64748b;
            padding: 8px;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
        }

        .btn-action:hover {
            background: #f3f4f6;
            color: #1e293b;
        }

        .customer-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #f59e0b 0%, #ea580c 100%);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 14px;
        }

        .search-box {
            position: relative;
        }

        .search-box i {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: #9ca3af;
        }

        .search-box input {
            padding-left: 40px;
            border-radius: 10px;
            border: 1px solid #e5e7eb;
        }

        .fade-in {
            animation: fadeIn 0.5s ease-in;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .quick-actions {
            background: linear-gradient(135deg, #f59e0b 0%, #ea580c 100%);
            color: white;
            padding: 24px;
            border-radius: 16px;
            margin-top: 24px;
        }

        .quick-actions h4 {
            margin: 0;
            font-weight: 600;
        }

        .quick-actions .btn-light {
            background: rgba(255,255,255,0.9);
            border: none;
            color: #1e293b;
            font-weight: 500;
        }

        .dropdown-menu {
            border: none;
            box-shadow: 0 10px 40px rgba(0,0,0,0.15);
            border-radius: 12px;
        }

        .dropdown-item {
            padding: 10px 16px;
            font-size: 14px;
        }

        .dropdown-item:hover {
            background: #f3f4f6;
        }

        .voided-row {
            background: #fef2f2 !important;
        }

        .voided-row td {
            text-decoration: line-through;
            color: #9ca3af;
        }

        .voided-amount {
            color: #dc2626;
            font-weight: 700;
            text-decoration: line-through;
        }

        .amount {
            color: #16a34a;
            font-weight: 700;
        }

        .void-reason {
            font-size: 12px;
            color: #dc2626;
            font-style: italic;
        }

        .timestamp {
            font-size: 12px;
            color: #9ca3af;
        }

        .staff-link {
            background: #fef3c7;
            color: #d97706;
            padding: 8px 16px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .staff-link:hover {
            background: #fcd34d;
            color: #92400e;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-brand">
            <h4><i class="fas fa-utensils me-2"></i>Cafè Erlinda</h4>
            <small class="text-muted">Admin Dashboard</small>
        </div>

        <div class="nav-menu">
            <div class="nav-item">
                <a href="index.php" class="nav-link <?php echo $current_page == 'index' ? 'active' : ''; ?>">
                    <i class="fas fa-home"></i>
                    <span>Dashboard</span>
                </a>
            </div>
            <div class="nav-item">
                <a href="table-bookings.php" class="nav-link <?php echo $current_page == 'table-bookings' ? 'active' : ''; ?>">
                    <i class="fas fa-calendar-alt"></i>
                    <span>Table Bookings</span>
                </a>
            </div>
            <div class="nav-item">
                <a href="catering.php" class="nav-link <?php echo $current_page == 'catering' ? 'active' : ''; ?>">
                    <i class="fas fa-glass-cheers"></i>
                    <span>Catering</span>
                </a>
            </div>
            <div class="nav-item">
                <a href="admin-orders.php" class="nav-link <?php echo $current_page == 'admin-orders' ? 'active' : ''; ?>">
                    <i class="fas fa-receipt"></i>
                    <span>Orders & Voids</span>
                    <span class="badge bg-danger ms-auto" style="font-size: 10px;">NEW</span>
                </a>
            </div>
            <div class="nav-item">
                <a href="menu.php" class="nav-link <?php echo $current_page == 'menu' ? 'active' : ''; ?>">
                    <i class="fas fa-utensils"></i>
                    <span>Menu</span>
                </a>
            </div>
            <div class="nav-item">
                <a href="settings.php" class="nav-link <?php echo $current_page == 'settings' ? 'active' : ''; ?>">
                    <i class="fas fa-cog"></i>
                    <span>Settings</span>
                </a>
            </div>
            <div class="nav-item mt-4">
                <a href="staff/staff-login.php" class="staff-link" target="_blank">
                    <i class="fas fa-user-tie"></i>
                    <span>Staff Portal</span>
                </a>
            </div>
            <div class="nav-item">
                <a href="logout.php" class="nav-link text-danger">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="topbar fade-in">
            <div>
                <h5 class="mb-0"><?php echo $page_title ?? 'Dashboard'; ?></h5>
                <small class="text-muted"><?php echo date('F d, Y'); ?></small>
            </div>
            <div class="d-flex align-items-center gap-3">
                <a href="staff/staff-login.php" class="staff-link" target="_blank">
                    <i class="fas fa-user-tie"></i>Open Staff Portal
                </a>
                <div class="text-end">
                    <p class="mb-0 fw-semibold"><?php echo htmlspecialchars($admin_name); ?></p>
                    <small class="text-muted"><?php echo htmlspecialchars($admin_role); ?></small>
                </div>
                <div class="customer-avatar">AD</div>
            </div>
        </div>
