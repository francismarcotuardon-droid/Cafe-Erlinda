<?php
$page_title = 'Orders & Voids';
require_once 'includes/header.php';

// Fetch all orders
$all_orders = [];
$orders_query = "SELECT o.*, s.full_name as staff_name 
               FROM orders o 
               LEFT JOIN staff s ON o.staff_id = s.staff_id 
               ORDER BY o.created_at DESC 
               LIMIT 100";
$orders_result = mysqli_query($conn, $orders_query);

if ($orders_result) {
    while ($row = mysqli_fetch_assoc($orders_result)) {
        $all_orders[] = $row;
    }
}

// Fetch void logs
$void_logs = [];
$logs_query = "SELECT v.*, o.customer_name, o.total_amount as order_amount 
               FROM void_logs v 
               LEFT JOIN orders o ON v.order_id = o.order_id 
               ORDER BY v.voided_at DESC 
               LIMIT 50";
$logs_result = mysqli_query($conn, $logs_query);

if ($logs_result) {
    while ($row = mysqli_fetch_assoc($logs_result)) {
        $void_logs[] = $row;
    }
}

// Calculate stats
$total_orders = count($all_orders);
$total_revenue = array_sum(array_filter(array_column($all_orders, 'total_amount'), fn($o) => $o['status'] ?? '' !== 'voided'));
$voided_count = count(array_filter($all_orders, fn($o) => $o['status'] === 'voided'));
$voided_amount = array_sum(array_column(array_filter($all_orders, fn($o) => $o['status'] === 'voided'), 'total_amount'));

function getStatusBadge($status) {
    $badges = [
        'pending' => '<span class="badge bg-warning text-dark"><i class="fas fa-clock me-1"></i>Pending</span>',
        'preparing' => '<span class="badge bg-info text-white"><i class="fas fa-fire me-1"></i>Preparing</span>',
        'ready' => '<span class="badge bg-primary"><i class="fas fa-bell me-1"></i>Ready</span>',
        'served' => '<span class="badge bg-success"><i class="fas fa-check-circle me-1"></i>Served</span>',
        'voided' => '<span class="badge bg-danger"><i class="fas fa-times-circle me-1"></i>Voided</span>',
    ];
    return $badges[$status] ?? '<span class="badge bg-secondary">' . ucfirst($status) . '</span>';
}
?>

<div class="fade-in">
    <div class="mb-4">
        <h4><i class="fas fa-receipt text-warning me-2"></i>Orders & Void Management</h4>
        <p class="text-muted">View all orders and voided transactions across staff</p>
    </div>

    <!-- Stats Cards -->
    <div class="row mb-4">
        <div class="col-md-3 mb-3">
            <div class="stat-card">
                <div class="stat-header">
                    <div>
                        <div class="stat-title">Total Orders</div>
                        <div class="stat-value"><?php echo $total_orders; ?></div>
                    </div>
                    <div class="stat-icon blue">
                        <i class="fas fa-receipt"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="stat-card">
                <div class="stat-header">
                    <div>
                        <div class="stat-title">Total Revenue</div>
                        <div class="stat-value text-green-600">$<?php echo number_format($total_revenue, 2); ?></div>
                    </div>
                    <div class="stat-icon green">
                        <i class="fas fa-dollar-sign"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="stat-card">
                <div class="stat-header">
                    <div>
                        <div class="stat-title">Voided Orders</div>
                        <div class="stat-value text-danger"><?php echo $voided_count; ?></div>
                    </div>
                    <div class="stat-icon red">
                        <i class="fas fa-times-circle"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="stat-card">
                <div class="stat-header">
                    <div>
                        <div class="stat-title">Voided Amount</div>
                        <div class="stat-value text-danger">$<?php echo number_format($voided_amount, 2); ?></div>
                    </div>
                    <div class="stat-icon red">
                        <i class="fas fa-ban"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Orders Table -->
    <div class="card mb-4">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0"><i class="fas fa-list-ul text-warning me-2"></i>All Orders</h5>
            <div class="search-box">
                <i class="fas fa-search"></i>
                <input type="text" class="form-control" placeholder="Search orders..." id="searchOrders">
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-container">
                <table class="table" id="ordersTable">
                    <thead>
                        <tr>
                            <th>Order #</th>
                            <th>Customer</th>
                            <th>Type</th>
                            <th>Items</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Staff</th>
                            <th>Created</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($all_orders)): ?>
                        <tr>
                            <td colspan="8" class="text-center py-4">
                                <i class="fas fa-receipt text-muted" style="font-size: 48px;"></i>
                                <p class="text-muted mt-2">No orders found</p>
                            </td>
                        </tr>
                        <?php else: ?>
                        <?php foreach ($all_orders as $order): ?>
                        <tr class="<?php echo $order['status'] === 'voided' ? 'voided-row' : ''; ?>">
                            <td><strong>#<?php echo $order['order_id']; ?></strong></td>
                            <td>
                                <div class="fw-semibold"><?php echo htmlspecialchars($order['customer_name']); ?></div>
                            </td>
                            <td><span class="text-capitalize"><?php echo str_replace('_', ' ', $order['order_type']); ?></span></td>
                            <td><small class="text-muted"><?php echo htmlspecialchars($order['items']); ?></small></td>
                            <td>
                                <?php if ($order['status'] === 'voided'): ?>
                                <span class="voided-amount">$<?php echo number_format($order['total_amount'], 2); ?></span>
                                <?php else: ?>
                                <span class="amount">$<?php echo number_format($order['total_amount'], 2); ?></span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo getStatusBadge($order['status']); ?></td>
                            <td><small class="text-muted"><?php echo htmlspecialchars($order['staff_name'] ?? 'Unknown'); ?></small></td>
                            <td><small class="timestamp"><?php echo date('M d, h:i A', strtotime($order['created_at'])); ?></small></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Void Logs Table -->
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0"><i class="fas fa-history text-danger me-2"></i>Void Audit Log</h5>
            <span class="badge bg-danger"><?php echo count($void_logs); ?> Records</span>
        </div>
        <div class="card-body p-0">
            <div class="table-container">
                <table class="table" id="voidLogsTable">
                    <thead>
                        <tr>
                            <th>Log #</th>
                            <th>Order #</th>
                            <th>Customer</th>
                            <th>Original Amount</th>
                            <th>Voided By</th>
                            <th>Void Reason</th>
                            <th>Voided At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($void_logs)): ?>
                        <tr>
                            <td colspan="7" class="text-center py-4">
                                <i class="fas fa-check-circle text-muted" style="font-size: 48px;"></i>
                                <p class="text-muted mt-2">No voided orders recorded</p>
                            </td>
                        </tr>
                        <?php else: ?>
                        <?php foreach ($void_logs as $log): ?>
                        <tr class="voided-row">
                            <td><strong>#<?php echo $log['log_id']; ?></strong></td>
                            <td><strong>#<?php echo $log['order_id']; ?></strong></td>
                            <td><?php echo htmlspecialchars($log['customer_name'] ?? 'Unknown'); ?></td>
                            <td><span class="voided-amount">$<?php echo number_format($log['order_amount'] ?? 0, 2); ?></span></td>
                            <td>
                                <div class="d-flex align-items-center gap-2">
                                    <div class="customer-avatar" style="width: 32px; height: 32px; font-size: 12px;">
                                        <?php echo strtoupper(substr($log['voided_by_name'], 0, 2)); ?>
                                    </div>
                                    <small><?php echo htmlspecialchars($log['voided_by_name']); ?></small>
                                </div>
                            </td>
                            <td>
                                <div class="void-reason">
                                    <i class="fas fa-quote-left me-1"></i>
                                    <?php echo htmlspecialchars($log['void_reason']); ?>
                                </div>
                            </td>
                            <td><small class="timestamp"><?php echo date('M d, h:i A', strtotime($log['voided_at'])); ?></small></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('searchOrders').addEventListener('input', function() {
    const searchTerm = this.value.toLowerCase();
    const rows = document.querySelectorAll('#ordersTable tbody tr');

    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(searchTerm) ? '' : 'none';
    });
});
</script>

<?php require_once 'includes/footer.php'; ?>
