<?php
$conn = mysqli_connect("localhost", "root", "", "cafe_erlinda");

if (!$conn) {
    die("Connection Failed: " . mysqli_connect_error());
}

// Set charset to handle special characters
mysqli_set_charset($conn, "utf8mb4");
?>
