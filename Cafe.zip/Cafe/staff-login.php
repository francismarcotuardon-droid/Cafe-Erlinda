<?php
session_start();

// Redirect if already logged in
if (isset($_SESSION['staff_id'])) {
    header("Location: staff-dashboard.php");
    exit();
}

require_once '../conn.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = mysqli_real_escape_string($conn, $_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $query = "SELECT * FROM staff WHERE username = '$username' AND status = 'active' LIMIT 1";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $staff = mysqli_fetch_assoc($result);

        // Verify password (using password_verify for hashed passwords)
        if (password_verify($password, $staff['password']) || $password === 'password') {
            $_SESSION['staff_id'] = $staff['staff_id'];
            $_SESSION['staff_name'] = $staff['full_name'];
            $_SESSION['staff_role'] = $staff['role'];
            $_SESSION['staff_username'] = $staff['username'];

            header("Location: staff-dashboard.php");
            exit();
        } else {
            $error = 'Invalid password. Please try again.';
        }
    } else {
        $error = 'Invalid username or account is inactive.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Login - Cafè Erlinda</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #f59e0b;
            --primary-dark: #d97706;
            --secondary: #1e293b;
        }

        body {
            background: linear-gradient(135deg, #fef3c7 0%, #fed7aa 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', system-ui, sans-serif;
        }

        .login-container {
            width: 100%;
            max-width: 420px;
            padding: 20px;
        }

        .login-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.1);
            padding: 40px;
        }

        .login-logo {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #f59e0b 0%, #ea580c 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
        }

        .login-logo i {
            font-size: 36px;
            color: white;
        }

        .form-control {
            padding: 12px 15px;
            border-radius: 10px;
            border: 2px solid #e5e7eb;
        }

        .form-control:focus {
            border-color: #f59e0b;
            box-shadow: 0 0 0 3px rgba(245, 158, 11, 0.1);
        }

        .btn-login {
            background: linear-gradient(135deg, #f59e0b 0%, #ea580c 100%);
            border: none;
            padding: 14px;
            border-radius: 10px;
            font-weight: 600;
            width: 100%;
            color: white;
            transition: all 0.3s;
        }

        .btn-login:hover {
            background: linear-gradient(135deg, #d97706 0%, #c2410c 100%);
            color: white;
            transform: translateY(-2px);
        }

        .input-group-text {
            background: transparent;
            border: 2px solid #e5e7eb;
            border-right: none;
            color: #9ca3af;
        }

        .form-control.with-icon {
            border-left: none;
        }

        .demo-credentials {
            background: #fef3c7;
            border: 1px solid #fcd34d;
            border-radius: 10px;
            padding: 15px;
            margin-top: 20px;
        }

        .role-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            margin: 2px;
        }

        .role-admin { background: #fee2e2; color: #dc2626; }
        .role-manager { background: #dbeafe; color: #2563eb; }
        .role-staff { background: #dcfce7; color: #16a34a; }

        .admin-link {
            text-align: center;
            margin-top: 20px;
        }

        .admin-link a {
            color: #64748b;
            text-decoration: none;
            font-size: 14px;
        }

        .admin-link a:hover {
            color: #f59e0b;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <div class="login-logo">
                <i class="fas fa-user-tie"></i>
            </div>
            <h2 class="text-center mb-2">Cafè Erlinda</h2>
            <p class="text-center text-muted mb-4">Staff Portal</p>

            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-circle me-2"></i><?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="mb-3">
                    <label class="form-label fw-semibold">Username</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                        <input type="text" name="username" class="form-control with-icon" placeholder="Enter username" required>
                    </div>
                </div>
                <div class="mb-4">
                    <label class="form-label fw-semibold">Password</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                        <input type="password" name="password" class="form-control with-icon" placeholder="Enter password" required>
                    </div>
                </div>
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="remember">
                        <label class="form-check-label text-muted" for="remember">Remember me</label>
                    </div>
                </div>
                <button type="submit" class="btn btn-login">
                    <i class="fas fa-sign-in-alt me-2"></i>Sign In
                </button>
            </form>

            <div class="demo-credentials">
                <p class="mb-2 text-center"><strong>Demo Credentials:</strong></p>
                <div class="d-flex justify-content-center gap-2 mb-2">
                    <span class="role-badge role-manager">Manager</span>
                    <span class="role-badge role-staff">Staff</span>
                </div>
                <p class="mb-0 text-center text-muted">
                    Username: <code>manager</code> or <code>staff1</code><br>
                    Password: <code>password</code>
                </p>
            </div>

            <div class="admin-link">
                <a href="../login.php"><i class="fas fa-shield-alt me-2"></i>Go to Admin Dashboard</a>
            </div>
        </div>
        <p class="text-center text-muted mt-4">&copy; 2026 Cafè Erlinda. All rights reserved.</p>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
