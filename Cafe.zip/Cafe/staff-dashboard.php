<?php
session_start();

// Check if staff is logged in
if (!isset($_SESSION['staff_id'])) {
    header("Location: staff-login.php");
    exit();
}

require_once '../conn.php';

$staff_id = $_SESSION['staff_id'];
$staff_name = $_SESSION['staff_name'];
$staff_role = $_SESSION['staff_role'];

$page_title = 'Staff Dashboard';

// Handle new order submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_order') {
    $customer_name = mysqli_real_escape_string($conn, $_POST['customer_name'] ?? '');
    $table_number = mysqli_real_escape_string($conn, $_POST['table_number'] ?? '');
    $order_type = mysqli_real_escape_string($conn, $_POST['order_type'] ?? 'dine_in');
    $items = mysqli_real_escape_string($conn, $_POST['items'] ?? '');
    $total_amount = (float)($_POST['total_amount'] ?? 0);
    $notes = mysqli_real_escape_string($conn, $_POST['notes'] ?? '');

    $insert_query = "INSERT INTO orders (customer_name, table_number, order_type, items, total_amount, notes, staff_id, status) 
                     VALUES ('$customer_name', '$table_number', '$order_type', '$items', $total_amount, '$notes', $staff_id, 'pending')";

    if (mysqli_query($conn, $insert_query)) {
        header("Location: staff-dashboard.php?success=order_created");
        exit();
    } else {
        $error = "Error creating order: " . mysqli_error($conn);
    }
}

// Handle void order
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'void_order') {
    $order_id = (int)$_POST['order_id'];
    $void_reason = mysqli_real_escape_string($conn, $_POST['void_reason'] ?? '');

    // Get order details before voiding
    $order_query = "SELECT * FROM orders WHERE order_id = $order_id";
    $order_result = mysqli_query($conn, $order_query);
    $order = mysqli_fetch_assoc($order_result);

    if ($order) {
        // Update order status to voided
        $update_query = "UPDATE orders SET status = 'voided', void_reason = '$void_reason', voided_by = $staff_id, voided_at = NOW() WHERE order_id = $order_id";

        if (mysqli_query($conn, $update_query)) {
            // Log the void action
            $log_query = "INSERT INTO void_logs (order_id, voided_by, voided_by_name, void_reason, original_amount) 
                         VALUES ($order_id, $staff_id, '$staff_name', '$void_reason', {$order['total_amount']})";
            mysqli_query($conn, $log_query);

            header("Location: staff-dashboard.php?success=order_voided");
            exit();
        } else {
            $error = "Error voiding order: " . mysqli_error($conn);
        }
    }
}

// Handle status update
if (isset($_GET['action']) && $_GET['action'] === 'update_status' && isset($_GET['id']) && isset($_GET['status'])) {
    $order_id = (int)$_GET['id'];
    $status = mysqli_real_escape_string($conn, $_GET['status']);

    $update_query = "UPDATE orders SET status = '$status' WHERE order_id = $order_id";
    mysqli_query($conn, $update_query);
    header("Location: staff-dashboard.php");
    exit();
}

// Fetch today's orders
$today_orders = [];
$today_query = "SELECT o.*, s.full_name as staff_name 
                FROM orders o 
                LEFT JOIN staff s ON o.staff_id = s.staff_id 
                WHERE DATE(o.created_at) = CURDATE() 
                ORDER BY o.created_at DESC";
$today_result = mysqli_query($conn, $today_query);

if ($today_result) {
    while ($row = mysqli_fetch_assoc($today_result)) {
        $today_orders[] = $row;
    }
}

// Fetch all active orders (non-voided)
$active_orders = [];
$active_query = "SELECT o.*, s.full_name as staff_name 
                FROM orders o 
                LEFT JOIN staff s ON o.staff_id = s.staff_id 
                WHERE o.status != 'voided' 
                ORDER BY o.created_at DESC 
                LIMIT 50";
$active_result = mysqli_query($conn, $active_query);

if ($active_result) {
    while ($row = mysqli_fetch_assoc($active_result)) {
        $active_orders[] = $row;
    }
}

// Fetch voided orders
$voided_orders = [];
$voided_query = "SELECT o.*, s.full_name as staff_name, v.voided_by_name, v.void_reason, v.voided_at as void_time
                FROM orders o 
                LEFT JOIN staff s ON o.staff_id = s.staff_id 
                LEFT JOIN void_logs v ON o.order_id = v.order_id
                WHERE o.status = 'voided' 
                ORDER BY o.voided_at DESC 
                LIMIT 50";
$voided_result = mysqli_query($conn, $voided_query);

if ($voided_result) {
    while ($row = mysqli_fetch_assoc($voided_result)) {
        $voided_orders[] = $row;
    }
}

// Calculate stats
$stats = [
    'today_total' => count($today_orders),
    'today_revenue' => array_sum(array_filter(array_column($today_orders, 'total_amount'), fn($o) => $o['status'] ?? '' !== 'voided')),
    'pending' => count(array_filter($active_orders, fn($o) => $o['status'] === 'pending')),
    'preparing' => count(array_filter($active_orders, fn($o) => $o['status'] === 'preparing')),
    'ready' => count(array_filter($active_orders, fn($o) => $o['status'] === 'ready')),
    'voided_today' => count(array_filter($today_orders, fn($o) => $o['status'] === 'voided'))
];

// Calculate today's actual revenue (excluding voided)
$today_revenue = 0;
foreach ($today_orders as $order) {
    if ($order['status'] !== 'voided') {
        $today_revenue += (float)$order['total_amount'];
    }
}

function getStatusBadge($status) {
    $badges = [
        'pending' => '<span class="badge bg-warning text-dark"><i class="fas fa-clock me-1"></i>Pending</span>',
        'preparing' => '<span class="badge bg-info text-white"><i class="fas fa-fire me-1"></i>Preparing</span>',
        'ready' => '<span class="badge bg-primary"><i class="fas fa-bell me-1"></i>Ready</span>',
        'served' => '<span class="badge bg-success"><i class="fas fa-check-circle me-1"></i>Served</span>',
        'voided' => '<span class="badge bg-danger"><i class="fas fa-times-circle me-1"></i>Voided</span>',
    ];
    return $badges[$status] ?? '<span class="badge bg-secondary">' . ucfirst($status) . '</span>';
}

function getOrderTypeIcon($type) {
    $icons = [
        'dine_in' => '<i class="fas fa-utensils text-primary"></i>',
        'takeout' => '<i class="fas fa-shopping-bag text-warning"></i>',
        'delivery' => '<i class="fas fa-motorcycle text-info"></i>',
    ];
    return $icons[$type] ?? '<i class="fas fa-utensils"></i>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - Cafè Erlinda Staff</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #f59e0b;
            --primary-dark: #d97706;
            --secondary: #1e293b;
            --success: #16a34a;
            --warning: #f59e0b;
            --danger: #ef4444;
            --info: #2563eb;
        }

        body {
            background: #f8fafc;
            font-family: 'Segoe UI', system-ui, sans-serif;
        }

        .staff-header {
            background: white;
            padding: 16px 24px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }

        .staff-brand {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .staff-brand h4 {
            color: var(--primary);
            margin: 0;
            font-weight: 700;
        }

        .staff-info {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .staff-avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #f59e0b 0%, #ea580c 100%);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 14px;
        }

        .role-badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .role-admin { background: #fee2e2; color: #dc2626; }
        .role-manager { background: #dbeafe; color: #2563eb; }
        .role-staff { background: #dcfce7; color: #16a34a; }

        .main-content {
            padding: 24px;
            max-width: 1400px;
            margin: 0 auto;
        }

        .stat-card {
            background: white;
            border-radius: 16px;
            padding: 24px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            height: 100%;
            transition: transform 0.2s;
        }

        .stat-card:hover {
            transform: translateY(-2px);
        }

        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }

        .stat-title {
            color: #64748b;
            font-size: 14px;
            font-weight: 500;
        }

        .stat-value {
            font-size: 32px;
            font-weight: 700;
            color: #1e293b;
            margin-top: 8px;
        }

        .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }

        .stat-icon.blue { background: #dbeafe; color: #2563eb; }
        .stat-icon.green { background: #dcfce7; color: #16a34a; }
        .stat-icon.amber { background: #fef3c7; color: #f59e0b; }
        .stat-icon.red { background: #fee2e2; color: #ef4444; }
        .stat-icon.purple { background: #f3e8ff; color: #9333ea; }

        .order-card {
            background: white;
            border-radius: 16px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        .order-card-header {
            padding: 20px 24px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .table-container {
            overflow-x: auto;
        }

        .table {
            margin: 0;
        }

        .table th {
            font-weight: 600;
            color: #64748b;
            border-bottom: 2px solid #e5e7eb;
            padding: 16px;
            background: #f8fafc;
        }

        .table td {
            padding: 16px;
            vertical-align: middle;
        }

        .table tbody tr:hover {
            background: #f8fafc;
        }

        .btn-action {
            background: none;
            border: none;
            color: #64748b;
            padding: 8px;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
        }

        .btn-action:hover {
            background: #f3f4f6;
            color: #1e293b;
        }

        .voided-row {
            background: #fef2f2 !important;
            opacity: 0.8;
        }

        .voided-row td {
            text-decoration: line-through;
            color: #9ca3af;
        }

        .void-reason {
            font-size: 12px;
            color: #dc2626;
            margin-top: 4px;
            font-style: italic;
        }

        .quick-actions {
            background: linear-gradient(135deg, #f59e0b 0%, #ea580c 100%);
            color: white;
            padding: 24px;
            border-radius: 16px;
            margin-bottom: 24px;
        }

        .quick-actions h4 {
            margin: 0;
            font-weight: 600;
        }

        .quick-actions .btn-light {
            background: rgba(255,255,255,0.9);
            border: none;
            color: #1e293b;
            font-weight: 500;
        }

        .quick-actions .btn-light:hover {
            background: white;
        }

        .fade-in {
            animation: fadeIn 0.5s ease-in;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .order-items {
            max-width: 250px;
            font-size: 13px;
            color: #64748b;
            line-height: 1.5;
        }

        .amount {
            font-weight: 700;
            color: #16a34a;
            font-size: 16px;
        }

        .voided-amount {
            font-weight: 700;
            color: #dc2626;
            font-size: 16px;
            text-decoration: line-through;
        }

        .nav-tabs-custom {
            border-bottom: 2px solid #e5e7eb;
            margin-bottom: 24px;
        }

        .nav-tabs-custom .nav-link {
            border: none;
            padding: 12px 24px;
            color: #64748b;
            font-weight: 500;
            border-bottom: 2px solid transparent;
            margin-bottom: -2px;
        }

        .nav-tabs-custom .nav-link:hover {
            color: var(--primary);
            border-bottom-color: var(--primary);
        }

        .nav-tabs-custom .nav-link.active {
            color: var(--primary);
            border-bottom-color: var(--primary);
            background: none;
        }

        .tab-content {
            padding: 0;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
        }

        .empty-state i {
            font-size: 64px;
            color: #d1d5db;
            margin-bottom: 16px;
        }

        .timestamp {
            font-size: 12px;
            color: #9ca3af;
        }

        .table-number {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            background: #f3f4f6;
            border-radius: 8px;
            font-weight: 600;
            font-size: 13px;
        }

        .search-box {
            position: relative;
            max-width: 300px;
        }

        .search-box i {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: #9ca3af;
        }

        .search-box input {
            padding-left: 40px;
            border-radius: 10px;
            border: 1px solid #e5e7eb;
        }

        .modal-content {
            border-radius: 16px;
            border: none;
        }

        .modal-header {
            border-bottom: 1px solid #e5e7eb;
            padding: 20px 24px;
        }

        .modal-footer {
            border-top: 1px solid #e5e7eb;
            padding: 16px 24px;
        }

        .form-control, .form-select {
            border-radius: 10px;
            border: 2px solid #e5e7eb;
            padding: 12px 15px;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(245, 158, 11, 0.1);
        }

        .btn-primary {
            background: linear-gradient(135deg, #f59e0b 0%, #ea580c 100%);
            border: none;
            padding: 10px 24px;
            border-radius: 10px;
            font-weight: 600;
        }

        .btn-primary:hover {
            background: linear-gradient(135deg, #d97706 0%, #c2410c 100%);
        }

        .btn-success {
            background: linear-gradient(135deg, #16a34a 0%, #15803d 100%);
            border: none;
        }

        .btn-danger {
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
            border: none;
        }

        .alert {
            border-radius: 12px;
            border: none;
        }

        .staff-footer {
            text-align: center;
            padding: 24px;
            color: #9ca3af;
            font-size: 14px;
            border-top: 1px solid #e5e7eb;
            margin-top: 40px;
        }
    </style>
</head>
<body>
    <!-- Staff Header -->
    <div class="staff-header">
        <div class="staff-brand">
            <i class="fas fa-utensils text-warning" style="font-size: 24px;"></i>
            <div>
                <h4>Cafè Erlinda</h4>
                <small class="text-muted">Staff Portal</small>
            </div>
        </div>
        <div class="staff-info">
            <span class="role-badge role-<?php echo $staff_role; ?>"><?php echo ucfirst($staff_role); ?></span>
            <div class="d-flex align-items-center gap-2">
                <div class="staff-avatar"><?php echo strtoupper(substr($staff_name, 0, 2)); ?></div>
                <div class="d-none d-md-block">
                    <div class="fw-semibold" style="font-size: 14px;"><?php echo htmlspecialchars($staff_name); ?></div>
                    <small class="text-muted"><?php echo date('F d, Y'); ?></small>
                </div>
            </div>
            <a href="staff-logout.php" class="btn btn-outline-secondary btn-sm">
                <i class="fas fa-sign-out-alt me-1"></i>Logout
            </a>
        </div>
    </div>

    <div class="main-content">
        <!-- Success/Error Messages -->
        <?php if (isset($_GET['success']) && $_GET['success'] === 'order_created'): ?>
        <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
            <i class="fas fa-check-circle me-2"></i>Order created successfully!
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <?php if (isset($_GET['success']) && $_GET['success'] === 'order_voided'): ?>
        <div class="alert alert-warning alert-dismissible fade show mb-4" role="alert">
            <i class="fas fa-exclamation-triangle me-2"></i>Order has been voided successfully.
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <?php if (isset($error)): ?>
        <div class="alert alert-danger alert-dismissible fade show mb-4" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Quick Actions -->
        <div class="quick-actions fade-in">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h4><i class="fas fa-concierge-bell me-2"></i>Order Management</h4>
                    <p class="mb-md-0">Create and manage customer orders</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <button class="btn btn-light me-2" data-bs-toggle="modal" data-bs-target="#createOrderModal">
                        <i class="fas fa-plus me-2"></i>New Order
                    </button>
                    <a href="../index.php" class="btn btn-light" target="_blank">
                        <i class="fas fa-chart-line me-2"></i>Admin Dashboard
                    </a>
                </div>
            </div>
        </div>

        <!-- Stats Row -->
        <div class="row fade-in mb-4">
            <div class="col-md-4 mb-3">
                <div class="stat-card">
                    <div class="stat-header">
                        <div>
                            <div class="stat-title">Today's Orders</div>
                            <div class="stat-value"><?php echo $stats['today_total']; ?></div>
                        </div>
                        <div class="stat-icon blue">
                            <i class="fas fa-receipt"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="stat-card">
                    <div class="stat-header">
                        <div>
                            <div class="stat-title">Today's Revenue</div>
                            <div class="stat-value text-green-600">$<?php echo number_format($today_revenue, 2); ?></div>
                        </div>
                        <div class="stat-icon green">
                            <i class="fas fa-dollar-sign"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="stat-card">
                    <div class="stat-header">
                        <div>
                            <div class="stat-title">Pending Orders</div>
                            <div class="stat-value text-amber-600"><?php echo $stats['pending']; ?></div>
                        </div>
                        <div class="stat-icon amber">
                            <i class="fas fa-clock"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Orders Tabs -->
        <div class="fade-in">
            <ul class="nav nav-tabs-custom" id="ordersTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="active-tab" data-bs-toggle="tab" data-bs-target="#active" type="button" role="tab">
                        <i class="fas fa-fire me-2"></i>Active Orders (<?php echo count($active_orders); ?>)
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="today-tab" data-bs-toggle="tab" data-bs-target="#today" type="button" role="tab">
                        <i class="fas fa-calendar-day me-2"></i>Today's Orders (<?php echo count($today_orders); ?>)
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="voided-tab" data-bs-toggle="tab" data-bs-target="#voided" type="button" role="tab">
                        <i class="fas fa-times-circle me-2"></i>Voided Orders (<?php echo count($voided_orders); ?>)
                    </button>
                </li>
            </ul>

            <div class="tab-content" id="ordersTabContent">
                <!-- Active Orders Tab -->
                <div class="tab-pane fade show active" id="active" role="tabpanel">
                    <div class="order-card">
                        <div class="order-card-header">
                            <h5 class="mb-0"><i class="fas fa-list-ul text-warning me-2"></i>Active Orders</h5>
                            <div class="search-box">
                                <i class="fas fa-search"></i>
                                <input type="text" class="form-control" placeholder="Search orders..." id="searchActive">
                            </div>
                        </div>
                        <div class="table-container">
                            <table class="table" id="activeTable">
                                <thead>
                                    <tr>
                                        <th>Order #</th>
                                        <th>Customer</th>
                                        <th>Type</th>
                                        <th>Items</th>
                                        <th>Table</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                        <th>Staff</th>
                                        <th class="text-end">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($active_orders)): ?>
                                    <tr>
                                        <td colspan="9">
                                            <div class="empty-state">
                                                <i class="fas fa-clipboard-list"></i>
                                                <h5>No active orders</h5>
                                                <p class="text-muted">Create a new order to get started</p>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php else: ?>
                                    <?php foreach ($active_orders as $order): ?>
                                    <tr data-status="<?php echo $order['status']; ?>">
                                        <td><strong>#<?php echo $order['order_id']; ?></strong></td>
                                        <td>
                                            <div class="fw-semibold"><?php echo htmlspecialchars($order['customer_name']); ?></div>
                                            <div class="timestamp"><?php echo date('h:i A', strtotime($order['created_at'])); ?></div>
                                        </td>
                                        <td><?php echo getOrderTypeIcon($order['order_type']); ?> <span class="text-capitalize"><?php echo str_replace('_', ' ', $order['order_type']); ?></span></td>
                                        <td><div class="order-items"><?php echo htmlspecialchars($order['items']); ?></div></td>
                                        <td>
                                            <?php if ($order['table_number']): ?>
                                            <span class="table-number"><i class="fas fa-chair"></i> <?php echo $order['table_number']; ?></span>
                                            <?php else: ?>
                                            <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><span class="amount">$<?php echo number_format($order['total_amount'], 2); ?></span></td>
                                        <td><?php echo getStatusBadge($order['status']); ?></td>
                                        <td><small class="text-muted"><?php echo htmlspecialchars($order['staff_name'] ?? 'Unknown'); ?></small></td>
                                        <td class="text-end">
                                            <div class="dropdown">
                                                <button class="btn-action" data-bs-toggle="dropdown">
                                                    <i class="fas fa-ellipsis-v"></i>
                                                </button>
                                                <ul class="dropdown-menu dropdown-menu-end">
                                                    <li><h6 class="dropdown-header">Update Status</h6></li>
                                                    <?php if ($order['status'] === 'pending'): ?>
                                                    <li><a class="dropdown-item" href="?action=update_status&id=<?php echo $order['order_id']; ?>&status=preparing"><i class="fas fa-fire me-2 text-info"></i>Start Preparing</a></li>
                                                    <?php endif; ?>
                                                    <?php if ($order['status'] === 'preparing'): ?>
                                                    <li><a class="dropdown-item" href="?action=update_status&id=<?php echo $order['order_id']; ?>&status=ready"><i class="fas fa-bell me-2 text-primary"></i>Mark Ready</a></li>
                                                    <?php endif; ?>
                                                    <?php if ($order['status'] === 'ready'): ?>
                                                    <li><a class="dropdown-item" href="?action=update_status&id=<?php echo $order['order_id']; ?>&status=served"><i class="fas fa-check-circle me-2 text-success"></i>Mark Served</a></li>
                                                    <?php endif; ?>
                                                    <li><hr class="dropdown-divider"></li>
                                                    <li>
                                                        <a class="dropdown-item text-danger" href="#" data-bs-toggle="modal" data-bs-target="#voidModal<?php echo $order['order_id']; ?>">
                                                            <i class="fas fa-times-circle me-2"></i>Void Order
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </td>
                                    </tr>

                                    <!-- Void Modal -->
                                    <div class="modal fade" id="voidModal<?php echo $order['order_id']; ?>" tabindex="-1">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title text-danger"><i class="fas fa-exclamation-triangle me-2"></i>Void Order #<?php echo $order['order_id']; ?></h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <form method="POST" action="">
                                                    <input type="hidden" name="action" value="void_order">
                                                    <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                                                    <div class="modal-body">
                                                        <div class="alert alert-warning">
                                                            <strong>Warning:</strong> This action cannot be undone. The order will be marked as voided and the amount will be deducted from revenue.
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label fw-semibold">Void Reason <span class="text-danger">*</span></label>
                                                            <textarea name="void_reason" class="form-control" rows="3" placeholder="Enter reason for voiding this order..." required></textarea>
                                                            <div class="form-text">This reason will be visible to admin and other staff members.</div>
                                                        </div>
                                                        <div class="p-3 bg-light rounded">
                                                            <div class="d-flex justify-content-between">
                                                                <span>Customer:</span>
                                                                <strong><?php echo htmlspecialchars($order['customer_name']); ?></strong>
                                                            </div>
                                                            <div class="d-flex justify-content-between mt-2">
                                                                <span>Amount:</span>
                                                                <strong class="text-danger">$<?php echo number_format($order['total_amount'], 2); ?></strong>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                                                        <button type="submit" class="btn btn-danger">
                                                            <i class="fas fa-times-circle me-2"></i>Void Order
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Today's Orders Tab -->
                <div class="tab-pane fade" id="today" role="tabpanel">
                    <div class="order-card">
                        <div class="order-card-header">
                            <h5 class="mb-0"><i class="fas fa-calendar-day text-warning me-2"></i>Today's Orders</h5>
                            <div class="search-box">
                                <i class="fas fa-search"></i>
                                <input type="text" class="form-control" placeholder="Search today's orders..." id="searchToday">
                            </div>
                        </div>
                        <div class="table-container">
                            <table class="table" id="todayTable">
                                <thead>
                                    <tr>
                                        <th>Order #</th>
                                        <th>Customer</th>
                                        <th>Type</th>
                                        <th>Items</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                        <th>Staff</th>
                                        <th>Time</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($today_orders)): ?>
                                    <tr>
                                        <td colspan="8">
                                            <div class="empty-state">
                                                <i class="fas fa-calendar-day"></i>
                                                <h5>No orders today</h5>
                                                <p class="text-muted">Orders placed today will appear here</p>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php else: ?>
                                    <?php foreach ($today_orders as $order): ?>
                                    <tr class="<?php echo $order['status'] === 'voided' ? 'voided-row' : ''; ?>">
                                        <td><strong>#<?php echo $order['order_id']; ?></strong></td>
                                        <td>
                                            <div class="fw-semibold"><?php echo htmlspecialchars($order['customer_name']); ?></div>
                                        </td>
                                        <td><?php echo getOrderTypeIcon($order['order_type']); ?> <span class="text-capitalize"><?php echo str_replace('_', ' ', $order['order_type']); ?></span></td>
                                        <td><div class="order-items"><?php echo htmlspecialchars($order['items']); ?></div></td>
                                        <td>
                                            <?php if ($order['status'] === 'voided'): ?>
                                            <span class="voided-amount">$<?php echo number_format($order['total_amount'], 2); ?></span>
                                            <?php else: ?>
                                            <span class="amount">$<?php echo number_format($order['total_amount'], 2); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo getStatusBadge($order['status']); ?></td>
                                        <td><small class="text-muted"><?php echo htmlspecialchars($order['staff_name'] ?? 'Unknown'); ?></small></td>
                                        <td><span class="timestamp"><?php echo date('h:i A', strtotime($order['created_at'])); ?></span></td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Voided Orders Tab -->
                <div class="tab-pane fade" id="voided" role="tabpanel">
                    <div class="order-card">
                        <div class="order-card-header">
                            <h5 class="mb-0"><i class="fas fa-times-circle text-danger me-2"></i>Voided Orders</h5>
                            <div class="search-box">
                                <i class="fas fa-search"></i>
                                <input type="text" class="form-control" placeholder="Search voided orders..." id="searchVoided">
                            </div>
                        </div>
                        <div class="table-container">
                            <table class="table" id="voidedTable">
                                <thead>
                                    <tr>
                                        <th>Order #</th>
                                        <th>Customer</th>
                                        <th>Items</th>
                                        <th>Amount</th>
                                        <th>Voided By</th>
                                        <th>Void Reason</th>
                                        <th>Voided At</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($voided_orders)): ?>
                                    <tr>
                                        <td colspan="7">
                                            <div class="empty-state">
                                                <i class="fas fa-check-circle"></i>
                                                <h5>No voided orders</h5>
                                                <p class="text-muted">Voided orders will appear here with reason and staff details</p>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php else: ?>
                                    <?php foreach ($voided_orders as $order): ?>
                                    <tr class="voided-row">
                                        <td><strong>#<?php echo $order['order_id']; ?></strong></td>
                                        <td>
                                            <div class="fw-semibold"><?php echo htmlspecialchars($order['customer_name']); ?></div>
                                        </td>
                                        <td><div class="order-items"><?php echo htmlspecialchars($order['items']); ?></div></td>
                                        <td><span class="voided-amount">$<?php echo number_format($order['total_amount'], 2); ?></span></td>
                                        <td>
                                            <div class="d-flex align-items-center gap-2">
                                                <div class="staff-avatar" style="width: 28px; height: 28px; font-size: 11px;">
                                                    <?php echo strtoupper(substr($order['voided_by_name'] ?? 'ST', 0, 2)); ?>
                                                </div>
                                                <small><?php echo htmlspecialchars($order['voided_by_name'] ?? 'Unknown'); ?></small>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="void-reason">
                                                <i class="fas fa-quote-left me-1"></i>
                                                <?php echo htmlspecialchars($order['void_reason'] ?? 'No reason provided'); ?>
                                            </div>
                                        </td>
                                        <td><span class="timestamp"><?php echo $order['void_time'] ? date('M d, h:i A', strtotime($order['void_time'])) : 'N/A'; ?></span></td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Create Order Modal -->
    <div class="modal fade" id="createOrderModal" tabindex="-1">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-plus-circle text-success me-2"></i>Create New Order</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="">
                    <input type="hidden" name="action" value="create_order">
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Customer Name <span class="text-danger">*</span></label>
                                <input type="text" name="customer_name" class="form-control" placeholder="Enter customer name" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Order Type <span class="text-danger">*</span></label>
                                <select name="order_type" class="form-select" required>
                                    <option value="dine_in">Dine In</option>
                                    <option value="takeout">Takeout</option>
                                    <option value="delivery">Delivery</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Table Number</label>
                                <input type="text" name="table_number" class="form-control" placeholder="e.g., T-05">
                                <div class="form-text">Leave empty for takeout/delivery</div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-semibold">Total Amount ($) <span class="text-danger">*</span></label>
                                <input type="number" name="total_amount" class="form-control" step="0.01" min="0" placeholder="0.00" required>
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-semibold">Order Items <span class="text-danger">*</span></label>
                                <textarea name="items" class="form-control" rows="3" placeholder="e.g., Classic Chicken Burger x2, Iced Caramel Latte x2" required></textarea>
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-semibold">Notes</label>
                                <textarea name="notes" class="form-control" rows="2" placeholder="Any special instructions..."></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-check me-2"></i>Create Order
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="staff-footer">
        <p>&copy; 2026 Cafè Erlinda. Staff Portal v1.0</p>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Search functionality for each table
        function setupSearch(inputId, tableId) {
            document.getElementById(inputId).addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase();
                const rows = document.querySelectorAll('#' + tableId + ' tbody tr');

                rows.forEach(row => {
                    const text = row.textContent.toLowerCase();
                    row.style.display = text.includes(searchTerm) ? '' : 'none';
                });
            });
        }

        setupSearch('searchActive', 'activeTable');
        setupSearch('searchToday', 'todayTable');
        setupSearch('searchVoided', 'voidedTable');

        // Auto-refresh page every 30 seconds to show new orders
        setTimeout(function() {
            location.reload();
        }, 30000);
    </script>
</body>
</html>
